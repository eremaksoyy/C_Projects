#include<stdio.h>
#include<stdlib.h>
#include <stdbool.h>
#include<string.h>
#define MAX_SIZE 200
#define SIZE 20
#include "avltree.h"


struct Data	{
	char name[SIZE] ;
	char dimension[SIZE] ;
	char size[SIZE] ;
	char city[SIZE] ;
	char country[SIZE] ;
	int year ;
};

AVLTree *ReadData(char *) ;

int main(int argc, char **argv)
{
	int option, *line ;
	char filename[SIZE] ;
	strcpy(filename, argv[1]) ;
	AVLTree *myAVLTree ;
	myAVLTree = CreateTree() ;
	myAVLTree = ReadData(filename) ;

	printf("\n>>>>>>>> Welcome to Photo Indexing <<<<<<<<\n\n") ;
	printf("\t--- MENU ---\n") ;
	printf("1. Display the full index of photos\n2. Display the photos of popular country\n3. Display the photos of popular year\n4. Exit\n\n") ;
	printf("Option:  ") ;
	scanf("%d", &option) ;
	do	{
		switch(option)	{
			case 1:
				DisplayIndex(myAVLTree) ;
				break ;
			case 2:
				PopularCountry(myAVLTree) ;
				break ;
			case 3:
				PopularYear(myAVLTree) ;
				break ;
			case 4:
				exit(1) ;
			default:
				printf("\nInvalid option entered!\n") ;
				break ;	}
		}	while(option>0 && option<4 ) ;
	return 0 ;
}

AVLTree *ReadData(char *filename)
{
	int line=0, i=0, digit=0 ;
	char array[MAX_SIZE] ;
	AVLTree *T ;
	T = CreateTree() ;

	FILE *inFile ;
	inFile = fopen(filename, "r") ;
	if(inFile == NULL)	{
		printf("Reading the file is not successful!\n") ;
		exit(1) ;	}
	while(fgets(array, sizeof(array), inFile))	{		//Here we count the lines of the file to create the data struct with enough memory.
		line++ ; }
	fclose(inFile) ;

	struct Data *data ;
	data = (struct Data *)malloc(line*sizeof(struct Data)) ;
	if(data == NULL)	{
		printf("Memory allocation is not successful!\n") ;
		exit(1) ;	}
	inFile = fopen(filename, "r") ;
		if(inFile == NULL)	{
		printf("Reading the file is not successful!\n") ;
		exit(1) ;	}

	while(!feof(inFile))	{		//Here we split the data like we do while using strtok function.
		fscanf(inFile, "%[^,],%[^,],%[^,],%[^,],%[^,],%d\n",data[i].name,data[i].dimension,data[i].size,data[i].city,data[i].country,&data[i].year) ;
		i++ ;	}

	while(digit != line)	{		//Here we insert tha data which is taken from the file to the tree.
		T = InsertPhoto(T,data[digit].name,data[digit].dimension,data[digit].size,data[digit].city,data[digit].country,data[digit].year) ;
		digit++ ;	}

	fclose(inFile) ;
	return T ;
}

