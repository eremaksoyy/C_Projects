
typedef struct TreeNode
{
	char *Name, *Dimension, *Size, *City, *Country ;
	int Year ;
	struct TreeNode *left;
	struct TreeNode *right;
	struct TreeNode *next;
	int height;
} AVLTree;


AVLTree *CreateTree()		//This function returns a null tree.
{
	return NULL ;
}

AVLTree *SingleRotateWithLeft(AVLTree *T)		//This function rotates the tree to right.
{
	AVLTree *temp ;
	temp = (AVLTree *)malloc(sizeof(AVLTree)) ;
	temp = T->left ;
	T->left = temp->right ;
	temp->right = T ;
	return T ;
}

AVLTree *SingleRotateWithRight(AVLTree *T)		//This function rotates the tree to left.
{
	AVLTree *temp;
	temp = (AVLTree *)malloc(sizeof(AVLTree)) ;
	temp = T->right ;
	T->right = temp->left ;
	temp->left = T ;
	return T ;
}

AVLTree *DoubleRotateWithLeft(AVLTree *T)		//This function rotates the tree first to left then to right.
{
	T->left = SingleRotateWithRight(T->left) ;
	T = SingleRotateWithLeft(T) ;
	return T ;
}

AVLTree *DoubleRotateWithRight(AVLTree *T)		//This function rotates the tree first to right then to left.
{
	T->right = SingleRotateWithLeft(T->right) ;
	T = SingleRotateWithRight(T) ;
	return T ;
}

void DisplayIndex(AVLTree *T)		//It displays the tree content in an alphabetical order.
{
    int counter=0, check=0;

    do{
       if(T != NULL)	{
            DisplayIndex(T->left) ;
            if(T->next!=NULL)	{
                AVLTree *temp ;
                temp = T ;
                while(temp->next != NULL)	{
                    printf("%-10s  %-10s  %-10s  %-10s  %-10s  %6d\n ", temp->next->Name, temp->next->Dimension, temp->next->Size, temp->next->City, temp->next->Country, temp->next->Year) ;
                    temp = temp->next ;	}   }
            printf("%-10s  %-10s  %-10s  %-10s  %-10s  %6d\n ", T->Name, T->Dimension, T->Size, T->City, T->Country, T->Year) ;
            if(counter==1){
                return true;  }

            DisplayIndex(T->right) ;
            counter++;
        }
    } while(false);

}

int FindHeight (AVLTree *T)	//This function finds the height.
{
	if (T != NULL)
		return T->height ;
	else
		return 0 ;
}

int Max(int x, int y)	//This function finds the max height (either left or right).
{
	if (x >= y)
		return x ;
	else
		return y ;
}

AVLTree *InsertPhoto(AVLTree *T, char *name, char *dimension, char *size, char *city, char *country, int year)		//This function takes the tree and all the information for the photo and insert it to the avl tree.
{
	int val ;
	if(T == NULL)	{
		T = (AVLTree *)malloc(sizeof(AVLTree)) ;
		if(T == NULL)	{
			printf("Out of memory space!\n") ;
			exit(1) ;	}
		else 	{
			T->Name = name ;
			T->Dimension = dimension ;
			T->Size = size ;
			T->City = city ;
			T->Country = country ;
			T->Year = year ;
			T->height = 1 ;
			T->left = T->right = NULL ;
			T->next = NULL ;	}	}
	else	{
		val = strcmp(country, T->Country) ;
		if(val==0)	{		//If another country with the same name comes, it inserts to the next node to keep them in the same tree node.
			T->next = InsertPhoto(T->next, name, dimension, size, city, country, year) ;	}
		if(val < 0)	{
			T->left = InsertPhoto(T->left, name, dimension, size, city, country, year) ;
			if(FindHeight(T->left)-FindHeight(T->right) == 2)	{
				if(val < 0)
					T = SingleRotateWithLeft(T) ;
				else
					T = DoubleRotateWithLeft(T) ;	}	}
		else if(val > 0)	{
			T->right = InsertPhoto(T->right, name, dimension, size, city, country, year) ;
			if(FindHeight(T->left)-FindHeight(T->right) == 0)	{
				if(val > 0)
					T = SingleRotateWithRight(T) ;
				else
					T = DoubleRotateWithRight(T) ;	}	}	}
	T->height = Max(FindHeight(T->left), FindHeight(T->right))+1 ;		//Here we update the height of the tree.
	return T ;
}


//For the complexity discussion, as we're doing search operation it takes O(logN) time where N represents the number of nodes that the tree has. So in this case it would be O(log4).
//I would improve to solve the infinite loop problem. It doesn't stop after displaying the neccessary informations.
void PopularCountry(AVLTree *T)		//This function displays the content of the popular country.
{
	if(T != NULL)	{
		PopularCountry(T->left) ;
		if(T->next!=NULL)	{
			AVLTree *temp ;
			temp = T ;
			printf("Photos of popular country:  \n") ;
			while(temp != NULL)	{
				printf("%-10s  %-10s  %-10s  %-10s  %-10s  %6d\n ", temp->Name, temp->Dimension, temp->Size, temp->City, temp->Country, temp->Year) ;
				temp = temp->next ;	}	}
		PopularCountry(T->right) ;	}
}


//For the complexity discussion, as we're doing search operation it takes O(logN) time where N represents the number of nodes that the tree has. So in this case it would be O(log4).
//I would improve to solve the infinite loop problem. It doesn't stop after displaying the neccessary informations.
void PopularYear(AVLTree *T)		//This function displays the photo informations of the popular year.
{
	int year ;
	AVLTree *temp ;
	temp = (AVLTree *)malloc(sizeof(AVLTree)) ;
	temp = T ;
	while(temp->right!=NULL || temp->left!=NULL)	{
		year = temp->Year ;
		if(temp->left != NULL)	{
			if(year == temp->left->Year)	{
				printf("Photos of popular year:  \n") ;
				printf("%-10s  %-10s  %-10s  %-10s  %-10s  %6d\n ", temp->Name, temp->Dimension, temp->Size, temp->City, temp->Country, temp->Year) ;
				printf("%-10s  %-10s  %-10s  %-10s  %-10s  %6d\n ", temp->left->Name, temp->left->Dimension, temp->left->Size, temp->left->City, temp->left->Country, temp->left->Year) ;	}
			temp = temp->left ;	}
		else if(temp->right != NULL)	{
			if(year == temp->right->Year)	{
				printf("Photos of popular year:  \n") ;
				printf("%-10s  %-10s  %-10s  %-10s  %-10s  %6d\n ", temp->Name, temp->Dimension, temp->Size, temp->City, temp->Country, temp->Year) ;
				printf("%-10s  %-10s  %-10s  %-10s  %-10s  %6d\n ", temp->right->Name, temp->right->Dimension, temp->right->Size, temp->right->City, temp->right->Country, temp->right->Year) ;	}
			temp = temp->right ;	}	}
}

