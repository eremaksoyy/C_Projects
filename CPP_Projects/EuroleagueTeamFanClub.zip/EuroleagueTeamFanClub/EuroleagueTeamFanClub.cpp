#include <iostream>
#include "EuroleagueTeamFanClub.h"

using std::cout;

EuroleagueTeamFanClub::EuroleagueTeamFanClub() {
	strcpy(name_of_the_team, "");
	year = 0;
	condition = P;
	strcpy(originCountry, "");
	NumberOfMembers = 0;	}

EuroleagueTeamFanClub::EuroleagueTeamFanClub(char* name, int y, char cond, char* origin, int member) {
//	cout << "Constructor is called!\n";
	name_of_the_team = new char[50];
	strcpy(name_of_the_team, name);
	if (cond == 'P')
		condition = P;
	else if (cond == 'S')
		condition = S;
	else
		cout << "Invalid input entered!";
	year = y;
	originCountry = new char[20];
	strcpy(originCountry, origin);
	NumberOfMembers = member;	}

EuroleagueTeamFanClub::EuroleagueTeamFanClub(const EuroleagueTeamFanClub& e) {
//	cout << "Copy constructor is called!\n";
	name_of_the_team = new char[50];
	strcpy(name_of_the_team, e.name_of_the_team);
	year = e.year;
	condition = e.condition;
	originCountry = new char[20];
	strcpy(originCountry, e.originCountry);
	NumberOfMembers = e.NumberOfMembers;	}

EuroleagueTeamFanClub::~EuroleagueTeamFanClub() {
//	cout<<"\nDestructor is called!\n";
	delete[] name_of_the_team;
	delete[] originCountry;	}

char* EuroleagueTeamFanClub::getName() {
	return this->name_of_the_team;	}

int EuroleagueTeamFanClub::getYear() {
	return this->year;	}

void EuroleagueTeamFanClub::getCondition() {
	if (this->condition == P)
		cout << "Pandemic continues\n";
	else
		cout << "Open for Supporters\n";	}

char* EuroleagueTeamFanClub::getCountry() {
	return this->originCountry;	}

int EuroleagueTeamFanClub::getMembers() {
	return NumberOfMembers;	}

void EuroleagueTeamFanClub::addFan(int m) {
	NumberOfMembers += m;	}

void EuroleagueTeamFanClub::printClub() {
	cout << "\nTeam Name: " << this->getName();
	cout << "\nYear: " << this->getYear();
	cout << "\nCondition: ";
	this->getCondition();
	cout << "Country: " << this->getCountry();
	cout << "\nThe Number of Members: " << this->getMembers();
	cout << "\n\n";	}

void EuroleagueTeamFanClub::differences(EuroleagueTeamFanClub& e) {
	operator==(*this, e);	}