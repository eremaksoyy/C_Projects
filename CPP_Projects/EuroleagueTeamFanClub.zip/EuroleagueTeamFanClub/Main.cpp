
#include <iostream>
#include<cstring>
#include "EuroleagueTeamFanClub.h"
using std::cin;
using std::cout;

void operator==(const EuroleagueTeamFanClub& a, const EuroleagueTeamFanClub& b) {
    if (strlen(a.name_of_the_team) == strlen(b.name_of_the_team)) {
        int i = 0, x = strlen(a.name_of_the_team);
        while (i != x) {
            if (a.name_of_the_team[i] != b.name_of_the_team[i]) {
                cout << "\nThe name of the team is different";
                break;    }
            i++;    }   }
    if (a.condition != b.condition)
        cout << "\nThe condition is different";
    if (strlen(a.originCountry) == strlen(b.originCountry)) {
        int i = 0, x = strlen(a.originCountry);
        while (i != x) {
            if (a.originCountry[i] != b.originCountry[i]) {
                cout << "\nThe origin of country is diffrent";
                break;   }
            i++;    }  }
    if (a.year != b.year)
        cout << "\nThe year is different";
    if (a.NumberOfMembers != b.NumberOfMembers)
        cout << "\nThe number of fans is different";    }

int main()
{
    EuroleagueTeamFanClub e1("Anadolu Efes", 2021, 'P', "Turkey", 2521);
    EuroleagueTeamFanClub e2("Anadolu Efes", 2022, 'P', "Turkey", 2712);
     e1.addFan(5);
     e1.printClub();
     e2.printClub();
     e1.differences(e2);
     cout << "\n\n";
}