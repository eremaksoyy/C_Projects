#pragma once
enum Conditions { P, S };

class EuroleagueTeamFanClub
{
private:
	char* name_of_the_team;
	int year;
	enum Conditions condition;
	char* originCountry;
	int NumberOfMembers;

public:
	EuroleagueTeamFanClub();
	EuroleagueTeamFanClub(char*, int, char, char*, int);
	EuroleagueTeamFanClub(const EuroleagueTeamFanClub&);
	~EuroleagueTeamFanClub();
	char* getName();
	int getYear();
	void getCondition();
	char* getCountry();
	int getMembers();
	void addFan(int);
	void printClub();
	friend void operator== (const EuroleagueTeamFanClub&, const EuroleagueTeamFanClub&);
	void differences(EuroleagueTeamFanClub&);
};

