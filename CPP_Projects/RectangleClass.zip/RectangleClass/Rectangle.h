#pragma once
class Rectangle
{
	private:
		float length;
		float width;
		char fill;
		char perim;
		void firstandlast();

	public:
		Rectangle();
		Rectangle(float, float);
		float perimeter();
		void area();
		void setLength(float);
		void setWidth(float);
		float getLength();
		float getWidth();
		void setFillCharacter(char);
		void setPerimeterCharacter(char);
		void draw();
};

