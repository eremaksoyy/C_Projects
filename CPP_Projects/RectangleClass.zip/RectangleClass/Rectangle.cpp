#include <iostream>
#include "Rectangle.h"

using std::cout;

Rectangle::Rectangle() {
	length = 1;
	width = 1;
	perim = '*';
	fill = '-';
	cout << "Values defaulted to 1!\n";
}

Rectangle::Rectangle(float w, float l) {
	if (l < 0)
		length = 0;
	else if (l > 20)
		length = 20;
	else
		length = l;

	if (w < 0)
		width = 0;
	else if (w > 20)
		width = 20;
	else
		width = w;

	perim = '*';
	fill = '-';
//	cout << "Custom Constructor!\n";
}

float Rectangle::perimeter() {
	return (length * 2) + (width * 2);
}

void Rectangle::area() {
	cout << "The area of this rectangle is: " << length * width << "\n";
}

void Rectangle::setLength(float l) {
	if (l < 0)
		length = 0;
	else if (l > 20)
		length = 20;
	else 
		length = l;
}

void Rectangle::setWidth(float w) {
	if (w < 0)
		width = 0;
	else if (w > 20)
		width = 20;
	else
		width = w;
}

float Rectangle::getLength() {
	return length;
}

float Rectangle::getWidth() {
	return width;
}

void Rectangle::setFillCharacter(char f) {
	fill = f;
}

void Rectangle::setPerimeterCharacter(char p) {
	perim = p;
}

void Rectangle::firstandlast() {
	int i;
	for (i = 0; i < width; i++)
		cout << perim;
}

void Rectangle::draw() {
	int l = (int)floor(length);
	int w = (int)floor(width);
//	int x = (int)width;
	int i, j;
	
//	first line
	cout << "\n";
	firstandlast();
/*	for (i = 0 ; i < width; i++)
		cout << perim;
*/	
//	in between
	for (i = 0; i < length-2; i++) {
		cout << "\n";
		for (j = 0; j < width; j++) {
			if (j == 0 || j == (width - 1))
				cout << perim;
			else
				cout << fill;
		}
	}
	cout << "\n";

//last line
	firstandlast();
/*	for (i = 0; i < width; i++)
		cout << perim;
*/
}

