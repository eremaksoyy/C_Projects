#include <iostream>
#include "Pair.h"

using std::cout;

Pair::Pair() {
	cout << "This is the constructor with no parameter\n" ;
	name = new char[50];
	strcpy(name, "Noname");
	age = 0;
}

char* Pair::getname() const{
	return name;
}

int Pair::getage() const{
	return age;
}

void Pair::setname(char* str) {
	strcpy(name, str);
}

void Pair::setage(int n) {
	age = n;
}

const int& Pair::getage2() {
	return age;
}