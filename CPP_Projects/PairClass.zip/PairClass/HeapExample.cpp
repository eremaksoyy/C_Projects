#include <iostream>
#include "Pair.h"

using namespace std;

void Pairprint(Pair p) {
	cout << "Name: " << p.getname() << ", Age: " << p.getage() << "\n";	}

void Pairprint2(const Pair& p) {
	cout << "\nThis is const pass by reference\n------------------\n" << "Name: " << p.getname() << "\nAge: " << p.getage() << "\n";	}

Pair initialize() {
	Pair temp;
	temp.setname("First Human");
	temp.setage(100);
	return temp;	}

void initialize2(Pair& p) {
	p.setname("Jane Fonda");
	p.setage(80);	}

ostream& operator<<(ostream& os, const Pair& p) {
	os << "\nUsing the operator\n------------------\n Name: " << p.name << ", Age: " << p.age << endl;
	return os;	}


int main()
{
	//The first case is to pass as a function parameter an object
	Pair p1;
	p1.setname("John Smith");
	p1.setage(25);
	Pairprint(p1); //Copy constructor is called to pass p1 to p
	//Destructor is called to destroy p1 inside the Pairprint method


	//The second case is to initialize an object
	Pair p2 = p1; //Copy constructor is called for initialization
	Pairprint(p2);	//Copy constructor is called to pass p2 to p (in the Pairprint method)
	//Destructor is called to destroy p2 inside the Pairprint method
	
	//The third case is to return
	Pair p3 = initialize(); //Copy constructor is called while returning from initialize to p3
	Pairprint(p3);	//Copy constructor is called  to pass p3 to p
	//Destructor is called four times to destroy p1, p2 (for the main for p1 and p2), and p3(one for the method, one for the main).

	Pair p4;
	p4.setname("Hakeem Olojuwan");
	p4.setage(50);
	p3 = p4; //It overloads the equal operator - overloading
	Pairprint(p3);

	cout << "\n\nPass by reference and const keyword\n-------------------------\n";
	Pair p5;
	initialize2(p5);
	Pairprint2(p5);
//	p5.getage2() = 1000; //This violates encapsulation. We should have access to private members like age here. So we'll use const keyword for getage2 function as a solution to this issue.
	Pairprint2(p5);
//	cout << p2 << endl;	//Using the operator, we are printing p2
	cout << p1 << p2 << p3 << p4 << p5 << endl; //We can print all by using the operator. This is how we can overload operators.

	return 0;
}
