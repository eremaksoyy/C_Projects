#pragma once
using namespace std;

class Pair
{
	private:
		char* name;
		int age;

	public:
		Pair();
		char* getname() const;
		int getage() const;
		void setname(char*);
		void setage(int);
		const int& getage2();
		friend ostream& operator <<(ostream&, const Pair &); //Function declaraion is in the main

		~Pair() {
			cout << "This is the destructor\n";
			delete[]name;	}

		Pair(Pair& p) {
			cout << "This is copy constructor\n";
			name = new char[50];
			strcpy(name, p.name);
			age = p.age;	}

		void operator = (Pair& p) {
			cout << "This is OVERLOADED = " << "\n";
			strcpy(name, p.name);
			age = p.age;
		}

};

