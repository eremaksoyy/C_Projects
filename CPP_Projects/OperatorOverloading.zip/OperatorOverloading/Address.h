#pragma once
#include<iostream>
#include<cstring>
#include<algorithm>
#include "Helpers.h"

using std::cout;
using std::copy;
using std::strlen;
using std::strcpy;
using std::istream;
using std::ostream;

enum Types { Anycast, Unicast, Multicast };
class Address
{
protected:	
	char FP[4];
	char TLA_ID[20];
	char Res[13];
	char NLA_ID[33];
	char SLA_ID[22];
	char InterfaceID[82];
	Address* Binary;
	char Hexa[40];
	enum Types type;

public:
	Address() {
		Binary = (Address*)malloc(sizeof(Address) * 1);
		strcpy(FP, "000");
		strcpy(Binary->FP, FP);
		strcpy(TLA_ID, "0 0000 0000 0000:");
		strcpy(Binary->TLA_ID, TLA_ID);
		strcpy(Res, "0000 0000 ");
		strcpy(Binary->Res, Res);
		strcpy(NLA_ID, "0000 0000:0000 0000 0000 0000:");
		strcpy(Binary->NLA_ID, NLA_ID);
		strcpy(SLA_ID, "0000 0000 0000 0000");
		strcpy(Binary->SLA_ID, SLA_ID);
		strcpy(InterfaceID, "0000 0000 0000 0000:0000 0000 0000 0000:0000 0000 0000 0000:0000 0000 0000 0000 ");
		strcpy(Binary->InterfaceID, InterfaceID);
		strcpy(Hexa, "0000:0000:0000:0000:0000:0000:0000:0000");
		strcpy(Binary->Hexa, Hexa);
	};

	Address(char* arr) {
		Binary = (Address*)malloc(sizeof(Address) * 1);
		char* a = (char*)calloc(163, 1);
		a = converter(arr);
	
		int i, counter=0;
		for (i = 0; i < 3; i++) {
 			FP[i] = a[i];
			counter++;
		}
		int j = 0;
		for (i; i < 20; i++) {
			TLA_ID[j] = a[i];
			counter++;
			if ((counter % 4 == 0) && i!=19) {
				TLA_ID[j+1] = ' ';
				i++;
				j++;
			}
			j++;
		}
		j = 0;
		for (i; i < 30; i++) {
			Res[j] = a[i];
			counter++;
			if ((counter % 4 == 0) && i != 29) {
				Res[j + 1] = ' ';
				i++;
				j++;
			}
			j++;
		}
		j = 0;
		for (i; i < 60; i++) {
			NLA_ID[j] = a[i];
			counter++;
			if ((counter % 4 == 0) && i != 59) {
				NLA_ID[j + 1] = ' ';
				i++;
				j++;
			}
			j++;
		}
		j = 0;
		for (i; i < 80; i++) {
			SLA_ID[j] = a[i];
			counter++;
			if ((counter % 4 == 0) && i != 79) {
				SLA_ID[j + 1] = ' ';
				i++;
				j++;
			}
			j++;
		}
		j = 0;
		for (i; i < 162; i++) {
			InterfaceID[j] = a[i];
			counter++;
			if ((counter % 4 == 0) && i != 161) {
				InterfaceID[j + 1] = ' ';
				i++;
				j++;
			}
			j++;
		}

		strcpy(Hexa, arr);
		strcpy(Binary->FP, FP);
		strcpy(Binary->TLA_ID, TLA_ID);
		strcpy(Binary->Res, Res);
		strcpy(Binary->NLA_ID, NLA_ID);
		strcpy(Binary->SLA_ID, SLA_ID);
		strcpy(Binary->InterfaceID, InterfaceID);
		strcpy(Binary->Hexa, Hexa);	}

	Address(const Address& address) {
		Binary = (Address*)malloc(sizeof(Address) * 1);
		strcpy(Binary->FP, address.Binary->FP);
		strcpy(Binary->TLA_ID, address.Binary->TLA_ID);
		strcpy(Binary->Res, address.Binary->Res);
		strcpy(Binary->NLA_ID, address.Binary->NLA_ID);
		strcpy(Binary->SLA_ID, address.Binary->SLA_ID);
		strcpy(Binary->InterfaceID, address.Binary->InterfaceID);
		strcpy(Binary->Hexa, address.Binary->Hexa);	}

	~Address() {};
	
	void setHexa(char* hex) {
		strcpy(Binary->Hexa, hex);	}

	void setType() {
		if (comp(Binary->FP, "000") || comp(Binary->FP, "010") || comp(Binary->FP, "011") || comp(Binary->FP, "100"))
			Binary->type = Anycast;
		else if (comp(Binary->FP, "001"))
			Binary->type = Unicast;
		else
			Binary->type = Multicast;	}
	
	void getType() {
		switch (type) {
		case Anycast:
			cout << "Anycast";
			break;
		case Unicast:
			cout << "Unicast";
			break;
		default:
			cout << "Multicast";	}	}

	char* getFP() {
		return Binary->FP;	}
	char* getTLA() {
		return Binary->TLA_ID;	}
	char* getRes() {
		return Binary->Res;	}
	char* getNLA() {
		return Binary->NLA_ID;	}
	char* getSLA() {
		return Binary->SLA_ID;	}
	char* getInterfaceID() {
		return Binary->InterfaceID;	}
	char* getHexa() {
		return Binary->Hexa;	}

	void operator ~() {
		switch (Binary->type) {
		case Anycast:
			cout << "Anycast";
			break;
		case Unicast:
			cout << "Unicast";
			break;
		default:
			cout << "Multicast";	}	}

	void operator!() {
		char Hexa_TLA[5];
		copy(Hexa, Hexa + 4, Hexa_TLA);
		Hexa_TLA[4] = '\0';
		cout << "Hexadecimal: " << Hexa_TLA;
		cout << "\nBinary: " << Binary->TLA_ID << endl;	}

	void operator++() {
		char Hexa_NLA[8];
		copy(Hexa + 7, Hexa + 14, Hexa_NLA);
		Hexa_NLA[7] = '\0';
		cout << "Hexadecimal: " << Hexa_NLA;
		cout << "\nBinary: " << Binary->NLA_ID << endl;	}

	void operator &() {
		char Hexa_SLA[5];
		copy(Hexa + 15, Hexa + 19, Hexa_SLA);
		Hexa_SLA[4] = '\0';
		cout << "Hexadecimal: " << Hexa_SLA;
		cout << "\nBinary: " << Binary->SLA_ID << endl;	}

	Address operator +(Address a1) {
		Address a;
		char* holder = (char*)calloc(79, 1);
		char* x, *y;
		x = (char*)calloc(79, 1);
		y = (char*)calloc(79, 1);
		strcpy(x, InterfaceID);
		strcpy(y, a1.Binary->InterfaceID);
		int i = 0, counter = 0;
		for (i; i < 79; i++) {
			if ((counter % 4 == 0) && (i != 0) && (counter != 0)) {
				holder[i] = ' ';
				i++;
			}
			if ((x[i] == '0') && (y[i] == '0'))
				holder[i] = '0';
			else
				holder[i] = '1';
			counter++;
		}
		holder[79] = '\0';
		strcpy(a.Binary->InterfaceID, holder);
		strcpy(a.Binary->Hexa, BinaryToHexa(holder));
		a.Binary->Hexa[19] = '\0';
		strcpy(a.Binary->FP, Binary->FP);
		strcpy(a.Binary->TLA_ID, Binary->TLA_ID);
		strcpy(a.Binary->Res, Binary->Res);
		strcpy(a.Binary->NLA_ID, Binary->NLA_ID);
		strcpy(a.Binary->SLA_ID, Binary->SLA_ID);
		strcpy(a.Binary->FP, Binary->FP);
		return a;	}	

	Address operator *(Address a1) {
		Address a;
		char* holder = (char*)calloc(79, 1);
		char* x, * y;
		x = (char*)calloc(79, 1);
		y = (char*)calloc(79, 1);
		strcpy(x, InterfaceID);
		strcpy(y, a1.Binary->InterfaceID);
		
		int i = 0, counter = 0;
		for (i; i < 79; i++) {
			if ((counter % 4 == 0) && (i != 0) && (counter != 0)) {
				holder[i] = ' ';
				i++;
			}
			if ((x[i] == '1') && (y[i] == '1'))
				holder[i] = '1';
			else
				holder[i] = '0';
			counter++;
		}
		holder[79] = '\0';
		strcpy(a.Binary->InterfaceID, holder);
		strcpy(a.Binary->Hexa, BinaryToHexa(holder));
		a.Binary->Hexa[19] = '\0';
		return a;	}	

	Address operator -(Address a1) {
		Address a;
		char* holder = (char*)calloc(79, 1);
		char* x, * y;
		x = (char*)calloc(79, 1);
		y = (char*)calloc(79, 1);
		strcpy(x, InterfaceID);
		strcpy(y, a1.Binary->InterfaceID);

		int i = 0, counter = 0;
		for (i; i < 79; i++) {
			if ((counter % 4 == 0) && (i != 0) && (counter != 0)) {
				holder[i] = ' ';
				i++;
			}
			if ((x[i] == '0') && (y[i] == '0'))
				holder[i] = '1';
			else
				holder[i] = '0';
			counter++;
		}
		holder[79] = '\0';
		strcpy(a.Binary->InterfaceID, holder);
		strcpy(a.Binary->Hexa, BinaryToHexa(holder));
		a.Binary->Hexa[19] = '\0';
		return a;	}

	Address operator /(Address a1) {
		Address a;
		char* holder = (char*)calloc(79, 1);
		char* x, * y;
		x = (char*)calloc(79, 1);
		y = (char*)calloc(79, 1);
		strcpy(x, InterfaceID);
		strcpy(y, a1.Binary->InterfaceID);

		int i = 0, counter = 0;
		for (i; i < 79; i++) {
			if ((counter % 4 == 0) && (i != 0) && (counter != 0)) {
				holder[i] = ' ';
				i++;
			}
			if ((x[i] == '1') && (y[i] == '1'))
				holder[i] = '0';
			else
				holder[i] = '1';
			counter++;
		}
		holder[79] = '\0';
		strcpy(a.Binary->InterfaceID, holder);
		strcpy(a.Binary->Hexa, BinaryToHexa(holder));
		a.Binary->Hexa[19] = '\0';
		return a;	}

	Address operator %(Address a1) {
		Address a;
		char* holder = (char*)calloc(79, 1);
		char* x, * y;
		x = (char*)calloc(79, 1);
		y = (char*)calloc(79, 1);
		strcpy(x, InterfaceID);
		strcpy(y, a1.Binary->InterfaceID);

		int i = 0, counter = 0;
		for (i; i < 79; i++) {
			if ((counter % 4 == 0) && (i != 0) && (counter != 0)) {
				holder[i] = ' ';
				i++;
			}
			if (((x[i] == '1') && (y[i] == '1')) || ((x[i] == '0') && (y[i] == '0')))
				holder[i] = '0';
			else
				holder[i] = '1';
			counter++;
		}
		holder[79] = '\0';
		strcpy(a.Binary->InterfaceID, holder);
		strcpy(a.Binary->Hexa, BinaryToHexa(holder));
		a.Binary->Hexa[19] = '\0';
		return a;	}

	Address operator ^(Address a1) {
		Address a;
		char* holder = (char*)calloc(79, 1);
		char* x, * y;
		x = (char*)calloc(79, 1);
		y = (char*)calloc(79, 1);
		strcpy(x, InterfaceID);
		strcpy(y, a1.Binary->InterfaceID);

		int i = 0, counter = 0;
		for (i; i < 79; i++) {
			if ((counter % 4 == 0) && (i != 0) && (counter != 0)) {
				holder[i] = ' ';
				i++;
			}
			if (((x[i] == '1') && (y[i] == '0')) || ((x[i] == '0') && (y[i] == '1')))
				holder[i] = '0';
			else
				holder[i] = '1';
			counter++;
		}
		holder[79] = '\0';
		strcpy(a.Binary->InterfaceID, holder);
		strcpy(a.Binary->Hexa, BinaryToHexa(holder));
		a.Binary->Hexa[19] = '\0';
		return a;	}

	friend ostream& operator<<(ostream& o, const Address a) {
		o << "\nHexadecimal" << endl;
		o << a.Binary->Hexa << endl;
		o << "\nBinary:\nFP, TLA, Res, NLA, SLA " << endl;
		o << a.Binary->FP << a.Binary->TLA_ID << a.Binary->Res << a.Binary->NLA_ID << a.Binary->SLA_ID;
		o << "\nInterface Identifier" << endl;
		o << a.Binary->InterfaceID << "\n\n";
		return o;	}

	bool operator==(const Address& a1) {
		int counter = 0;
		if (comp(Binary->FP, a1.Binary->FP)) {
			cout << "\nFP: " << Binary->FP;
			counter++;
		}
		if (comp(Binary->TLA_ID, a1.Binary->TLA_ID)) {
			cout << "\nTLA: " << Binary->TLA_ID;
			counter++;
		}
		if (comp(Binary->Res, a1.Binary->Res)) {
			cout << "\nRes: " << Binary->Res;
			counter++;
		}
		if (comp(Binary->NLA_ID, a1.Binary->NLA_ID)) {
			cout << "\nNLA: " << Binary->NLA_ID;
			counter++;
		}
		if (comp(Binary->SLA_ID, a1.Binary->SLA_ID)) {
			cout << "\nSLA: " << Binary->SLA_ID;
			counter++;
		}
		if (comp(Binary->InterfaceID, a1.Binary->InterfaceID)) {
			cout << "\nInterface Identifier: " << Binary->InterfaceID;
			counter++;
		}
		if (comp(Binary->Hexa, a1.Binary->Hexa)) {
			cout << "\nHexadecimal: " << Binary->Hexa;
			counter++;
		}
		if (counter == 7)
			return true;
		else
			return false;
	}

	bool operator!=(const Address& a1) {
		int counter = 0;
		if (!comp(Binary->FP, a1.Binary->FP)) {
			cout << "\nFP: " << Binary->FP;
			counter++;
		}
		if (!comp(Binary->TLA_ID, a1.Binary->TLA_ID)) {
			cout << "\nTLA: " << Binary->TLA_ID;
			counter++;
		}
		if (!comp(Binary->Res, a1.Binary->Res)) {
			cout << "\nRes: " << Binary->Res;
			counter++;
		}
		if (!comp(Binary->NLA_ID, a1.Binary->NLA_ID)) {
			cout << "\nNLA: " << Binary->NLA_ID;
			counter++;
		}
		if (!comp(Binary->SLA_ID, a1.Binary->SLA_ID)) {
			cout << "\nSLA: " << Binary->SLA_ID;
			counter++;
		}
		if (!comp(Binary->InterfaceID, a1.Binary->InterfaceID)) {
			cout << "\nInterface Identifier: " << Binary->InterfaceID;
			counter++;
		}
		if (!comp(Binary->Hexa, a1.Binary->Hexa)) {
			cout << "\nHexadecimal: " << Binary->Hexa;
			counter++;
		}
		if (counter != 7)
			return false;
		else 
			return true;
	}

	friend istream& operator>>(istream& i, const Address a) {
		cout << "\nPlease enter Address in Hexadecimal, separated with ':' every 4 digits: " << endl;
		i >> a.Binary->Hexa;
		cout << "\nSuccessfully created!" << endl;
		cout << "\nBinary representation of the address entered: \n" << converter(a.Binary->Hexa) << endl;
		return i;	}
};

	

	