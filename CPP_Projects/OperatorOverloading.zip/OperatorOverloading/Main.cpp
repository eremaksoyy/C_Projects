
#include <iostream>
#include<cstring>
#include "Address.h"
#include "Helpers.h"

using std::cin;
using std::cout;
using std::endl;

int main()
{
	// A1 = 1080:0012:3456:789A:FEDC:BA98:765C:737A
	// A2 = 2080:00FE:3456:789A:FEDC:BA98:7654:3210

	char* a1 = (char*)calloc(39, 1);
	char* a2 = (char*)calloc(39, 1);
	char* new_a1 = (char*)calloc(39, 1);
	char* new_a2 = (char*)calloc(39, 1);
	cout << "For A1:\nPlease enter Address in Hexadecimal, separated with ':' evet 4 digits:" << endl;
	cin >> a1;
	while (strlen(a1) != 39) {
		cout << "\nInvalid input! Length of input must be 39 characters!\nPlease re-enter:" << endl;
		cin >> a1;	}
	Address A1(a1);
	cout << "\nSuccessfully created!" << endl;
	cout << "\n--------------------------------------------------" << endl;
	cout << "For A2:\nPlease enter Address in Hexadecimal, separated with ':' evet 4 digits:" << endl;
	cin >> a2;
	while (strlen(a2) != 39) {
		cout << "\nInvalid input! Length of input must be 39 characters!\nPlease re-enter:" << endl;
		cin >> a2;	}
	Address A2(a2);
	cout << "\nSuccessfully created!" << endl;
	cout << "\n--------------------------------------------------" << endl;
	Address A3, OR, AND, NOR, NAND, XOR, XNOR;
	int choice, num, i;
	do {
		menu();
		cout << "\nPlease Select: ";
		cin >> choice;
		switch (choice) {
		case 'a':
			cout << "\nEnter the new address for A1: ";
			cin >> new_a1;
			A1.setHexa(new_a1);
			break;
		case 'b':
			cout << "\nEnter the new address for A2: ";
			cin >> new_a2;
			A2.setHexa(new_a2);
			break;
		case 1:
			cout << "\nPlease enter 1 for A1, 2 for A2: ";
			cin >> num;
			if (num == 1) {
				cout << "Classification for A1 is: ";
				A1.setType();
				~A1;	}
			else if (num == 2) {
				cout << "Classification for A2 is: ";
				A2.setType();
				~A2;	}
			else
				cout << "Invalid value entered!\n ";
			break;
		case 2:
			cout << "\nPlease enter 1 for A1, 2 for A2: ";
			cin >> num;
			if (num == 1) {
				cout << "TLA ID of A1 " << endl;
				!A1;	}
			else if (num == 2) {
				cout << "TLA ID of A2 " << endl;
				!A2;	}
			else 
				cout << "Invalid value entered!\n ";
			break;
		case 3:
			cout << "\nPlease enter 1 for A1, 2 for A2: ";
			cin >> num;
			if (num == 1) {
				cout << "NLA ID of A1 " << endl;
				++A1;;	}
			else if (num == 2) {
				cout << "NLA ID of A2 " << endl;
				++A2;	}
			else
				cout << "Invalid value entered!\n ";
			break;
		case 4:
			cout << "\nPlease enter 1 for A1, 2 for A2: ";
			cin >> num;
			if (num == 1) {
				cout << "SLA ID of A1 " << endl;
				&A1;	}
			else if (num == 2) {
				cout << "SLA ID of A2 " << endl;
				&A2;	}
			else
				cout << "Invalid value entered!\n ";
			break;
		case 5:
			cout << "\nResult of A1 + A2 ; " << endl;
			OR = A1.operator+(A2);
			cout << OR;
			break;
		case 6:
			cout << "\nResult of A1 * A2 ; " << endl;
			AND = A1.operator*(A2);
			cout << AND;
			break;
		case 7:
			cout << "\nResult of A1 - A2 ; " << endl;
			NOR = A1.operator-(A2);
			cout << NOR;
			break;
		case 8:
			cout << "\nResult of A1 / A2 ; " << endl;
			NAND = A1.operator/(A2);
			cout << NAND;
			break;
		case 9:
			cout << "\nResult of A1 % A2 ; " << endl;
			XOR = A1.operator%(A2);
			cout << XOR;
			break;
		case 10:
			cout << "\nResult of A1 ^ A2 ; " << endl;
			XNOR = A1.operator^(A2);
			cout << XNOR;
			break;
		case 11:
			cout << "\nCreating a new object(A3)! \nA3 is created" << endl;
			cout << "\nContents of A3:" << endl;
			cout << A3;
			cout << "\nContents of A1: " << endl;
			cout << A1;
			cout << "\nAfter A3 = A1:" << endl;
			A3 = Address(A1);
			cout << "Contents of A3:" << endl;
			cout << A3;
			cout << "\nContents of A1: " << endl;
			cout << A1;
			break;
		case 12:
			cout << "Same sections: ";
			i = (A1 == A2);
			if (i)
				cout << "\nResult of A1 == A2: true";
			else
				cout << "\nResult of A1 == A2: false";
			break;
		case 13:
			cout << "Different sections: ";
			i = (A1 != A2);
			if (i)
				cout << "\nResult of A1 != A2: true";
			else
				cout << "\nResult of A1 != A2: false";
			break;
		case 14:
			cout << "\nPlease enter 1 for A1, 2 for A2: ";
			cin >> num;
			if (num == 1)
				cout << A1;
			else if (num == 2)
				cout << A2;
			else
				cout << "Invalid value entered!\n ";
			break;
		case 15:
			cout << "\nPlease enter 1 for A1, 2 for A2: ";
			cin >> num;
			if (num == 1)
				cin >> A1;
			else if (num == 2)
				cin >> A2;
			else
				cout << "Invalid value entered!\n ";
			break;
		case 0:
			cout << "Good bye!" << endl;
			exit(1);
			break;
		default:
			cout << "Invalid input entered! Try again!" << endl;
			break;
		}
	} while (choice != 0);

	return 0;
}
