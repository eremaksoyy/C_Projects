#pragma once
#include <iostream>
#include <cstring>
#include<algorithm>
#include "Address.h"

using std::cout;
using std::copy;
using std::endl;

char* conc(char* aim, const char* source) {
	char* ptr = aim + strlen(aim);
	while (*source != '\0') {
		*ptr++ = *source++;
	}
	return aim;
}

bool comp(char* a, char* b) {
	if (strlen(a) != strlen(b)) {
		return false;
	}
	else {
		int x = strlen(a);
		for (int i = 0; i < x; i++) {
			if (a[i] == b[i])
				continue;
			else
				return false;
		}
		return true;
	}
}

char* converter(char* a) {
	int counter, i, j=0;
	char c;
	char* holder = (char*)calloc(163, 1);
	
	counter = 0;
	for (i = 0; i < 39; i++) {
		if ((counter % 4 == 0) && (i != 0) && (counter != 0)) {
			conc(holder, ":");
			i++;
		}
		else if(counter!=0)
			conc(holder, " ");
		c = a[i];
		switch (c) {
		case '0':
			conc(holder, "0000");
			break;
		case '1':
			conc(holder, "0001");
			break;
		case '2':
			conc(holder, "0010");
			break;
		case '3':
			conc(holder, "0011");
			break;
		case '4':
			conc(holder, "0100");
			break;
		case '5':
			conc(holder, "0101");
			break;
		case '6':
			conc(holder, "0110");
			break;
		case '7':
			conc(holder, "0111");
			break;
		case '8':
			conc(holder, "1000");
			break;
		case '9':
			conc(holder, "1001");
			break;
		case 'A':
			conc(holder, "1010");
			break;
		case 'B':
			conc(holder, "1011");
			break;
		case 'C':
			conc(holder, "1100");
			break;
		case 'D':
			conc(holder, "1101");
			break;
		case 'E':
			conc(holder, "1110");
			break;
		default:
			conc(holder, "1111");
			break;
		}
		counter++;
	}
	return holder;
}

char* BinaryToHexa(char* a) {
	int counter = 0, i = 0, j = 0;
	char* holder = (char*)calloc(40, 1);
	char* keep = (char*)calloc(5, 1);
	for (i; i < 39; i++) {
		if ((counter % 4 == 0) && (i != 0) && (counter != 0)) {
			conc(holder, ":");
			i++;
		}
		copy(a+j, a+j+4, keep);
		j += 5;
		keep[4] = '\0';
		if (comp(keep, "0000"))
			holder[i] = '0';
		else if (comp(keep, "0001"))
			holder[i] = '1';
		else if (comp(keep, "0010"))
			holder[i] = '2';
		else if (comp(keep, "0011"))
			holder[i] = '3';
		else if (comp(keep, "0100"))
			holder[i] = '4';
		else if (comp(keep, "0101"))
			holder[i] = '5';
		else if (comp(keep, "0110"))
			holder[i] = '6';
		else if (comp(keep, "0111"))
			holder[i] = '7';
		else if (comp(keep, "1000"))
			holder[i] = '8';
		else if (comp(keep, "1001"))
			holder[i] = '9';
		else if (comp(keep, "1010"))
			holder[i] = 'A';
		else if (comp(keep, "1011"))
			holder[i] = 'B';
		else if (comp(keep, "1100"))
			holder[i] = 'C';
		else if (comp(keep, "1101"))
			holder[i] = 'D';
		else if (comp(keep, "1110"))
			holder[i] = 'E';
		else if (comp(keep, "1111"))
			holder[i] = 'F';
		counter++;
	}
	return holder;
}

void menu() {
	cout << "\n--------------------------------------------------" << endl;
	cout << "a. Change first address(A1)" << endl;
	cout << "b. Change second address(A2)" << endl;
	cout << "1. Print the result of classification" << endl;
	cout << "2. Print TLA ID" << endl;
	cout << "3. Print NLA ID" << endl;
	cout << "4. Print SLA ID" << endl;
	cout << "5. Bitwise disjunction" << endl;
	cout << "6. Bitwise conjuction" << endl;
	cout << "7. Bitwise NOR" << endl;
	cout << "8. Bitwise NAND" << endl;
	cout << "9. Bitwise XOR" << endl;
	cout << "10. Bitwise XNOR" << endl;
	cout << "11. Copy Contents of first address to another" << endl;
	cout << "12. Compare if A1 == A2 " << endl;
	cout << "13. Compare if A1 != A2 " << endl;
	cout << "14. Print address" << endl;
	cout << "15. Enter an address" << endl;
	cout << "0. Exit" << endl;
}
