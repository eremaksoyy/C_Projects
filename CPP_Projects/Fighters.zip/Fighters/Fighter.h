#pragma once
#include <iostream>

class Fighter
{
private:
	int healthbar;
	bool lost;

public:
	Fighter();
	Fighter(int fighterHealthbar);
	virtual void setAttackPower(int) = 0;
	virtual int getAttackPower(void) = 0;
	virtual void print(void) = 0;
	void setHealthbar(int);
	int getHealthbar() const;
	void updateHealthbar(int);
	bool isLost() const;
};

class Haohmaru : public Fighter {
private:
	int attackPower;

public: 
	Haohmaru(int a) :Fighter(a) {
		this->setHealthbar(a);
	}
	void setAttackPower(int);
	int getAttackPower();
	void print();
};

class Genjuro : public Fighter {
private:
	int attackPower;
public:
	Genjuro(int b) :Fighter(b) {
		this->setHealthbar(b);
	}
	void setAttackPower(int);
	int getAttackPower();
	void print();
};
