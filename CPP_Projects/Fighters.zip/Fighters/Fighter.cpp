#include<iostream>
#include "Fighter.h"

using std::cout;

Fighter::Fighter() {
	healthbar = 0;
	lost = false;
}

Fighter::Fighter(int fighterHealthbar) {
	healthbar = fighterHealthbar;
	lost = false;
}

void Haohmaru::setAttackPower(int power) {
	attackPower = power;
}

void Genjuro::setAttackPower(int power) {
	attackPower = power;
}

int Haohmaru::getAttackPower() {
	return this->attackPower;
}

int Genjuro::getAttackPower() {
	return this->attackPower;
}

void Haohmaru::print() {
	cout << "Haohmaru's current stamina: " << this->getHealthbar() << "\n";
}

void Genjuro::print() {
	cout << "Genjuro's current stamina: " << this->getHealthbar() << "\n";
}

void Fighter::setHealthbar(int a) {
	this->healthbar = a;
}

int Fighter::getHealthbar() const {
	return this->healthbar;
}

void Fighter::updateHealthbar(int power) {
	int currentHealth = this->getHealthbar();
	this->healthbar = currentHealth - power;
}

bool Fighter::isLost() const {
	if (this->healthbar <= 0)
		return true;
	else
		return false;
}


