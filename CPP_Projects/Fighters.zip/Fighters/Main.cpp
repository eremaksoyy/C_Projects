
#include <iostream>
#include "Fighter.h"

using std::cout;
using std::cin;

int main()
{
	int firstPlayer, finish;
	char choice = 'y';
	int f1_power, f2_power, f1_health, f2_health;

	do {
		cout << "\nGenjuro's attack power: ";
		cin >> f1_power;
		cout << "Genjuro's max health(healthbar): ";
		cin >> f1_health;

		cout << "Haohmaru's attack power: ";
		cin >> f2_power;
		cout << "Haohmaru's max health(healthbar): ";
		cin >> f2_health;

		Genjuro playerG(f1_health);
		Haohmaru playerH(f2_health);

		Fighter* ptr_F1 = &playerG;
		Fighter* ptr_F2 = &playerH;

		ptr_F1->setAttackPower(f1_power);
		ptr_F2->setAttackPower(f2_power);

		cout << "Who goes first?\n  Genjuro(1), Haohmaru(2): ";
		cin >> firstPlayer;
		cout << "\n";

		finish = 0;
		switch (firstPlayer) {
		case 1:
			//Genjuros attacks first
			while (finish != 1) {
				cout << "Genjuro's attack!\n";
				playerH.updateHealthbar(playerG.getAttackPower());
				playerH.print();
				if (playerG.isLost()) {
					cout << "\nGenjuro lost!\nHaohmaru won!\n";
					finish = 1;
					break;
				}
				else if (playerH.isLost()) {
					cout << "\nHaohmaru lost!\nGenjuro won!\n";
					finish = 1;
					break;
				}
				cout << "Haohmaru's attack!\n";
				playerG.updateHealthbar(playerH.getAttackPower());
				playerG.print();
				if (playerG.isLost()) {
					cout << "\nGenjuro lost!\nHaohmaru won!\n";
					finish = 1;
					break;
				}
				else if (playerH.isLost()) {
					cout << "\nHaohmaru lost!\nGenjuro won!\n";
					finish = 1;
					break;
				}
			}
			break;

		case 2:
			//Haohmaru attacks first
			while (finish != 1) {
				cout << "Haohmaru's attack!\n";
				playerG.updateHealthbar(playerH.getAttackPower());
				playerG.print();
				if (playerG.isLost()) {
					cout << "\nGenjuro lost!\nHaohmaru won!\n";
					finish = 1;
					break;
				}
				else if (playerH.isLost()) {
					cout << "\nHaohmaru lost!\nGenjuro won!\n";
					finish = 1;
					break;
				}
				cout << "Genjuro's attack!\n";
				playerH.updateHealthbar(playerG.getAttackPower());
				playerH.print();
				if (playerG.isLost()) {
					cout << "\nGenjuro lost!\nHaohmaru won!\n";
					finish = 1;
					break;
				}
				else if (playerH.isLost()) {
					cout << "\nHaohmaru lost!\nGenjuro won!\n";
					finish = 1;
					break;
				}
			}
			break;

		default:
			cout << "Invalid value entered! Try again\n\n";
			break;
		}

		cout << "\nWould you like to play again? (y/n): ";
		cin >> choice;

	} while ((choice == 'y'));
	if (choice != 'n')
		cout << "Invalid value entered!!\n";
	else
		cout << "\nGoodbye!\n";
}
