/* Fatma Erem Aksoy - 2315075 / Ece Erseven - 2385383
I read and accept the submission rules and the important section specified in assignment file.
This is my own work that is done by myself and my team-mate only */

#include <iostream>
#include <cstring>
#include "LinkedList.h"
#include "Entity.h"
#include "Zombies.h"
#include "Resources.h"
#include "Warrior.h"
#include "Derick.h"
#include "Chichonne.h"
#include "Grid.h"

using std::cin;
using std::cout;
using std::endl;

//Battle function 
void Battle(LinkedList* LZombie, LinkedList* LResource) {
    int diceVal, ZombieDamage, finish, player, counter = 0;
    srand(time(0));
    Derick D;
    Warrior* W1 = &D;
    Chichonne C;
    Warrior* W2 = &C;
    LinkedList ListDerick, ListChichonne;       //creates the linked lists for both warriors Derick and Chichonne to save the zombie types

    int sizeResource = LResource->getLength();      //size of the resources linked list 
    int ListSize = LZombie->getLength();        //size of the zombies linked list 

    cout << "Please select a warrior to start (1)Derick, (2)Chichonne: ";
    cin >> player;

    finish = 0;
    switch (player)
    {
    case 1:
        //Derick is playing

        for (int i = 0; i < sizeResource; i++) {        //makes necessary changes according to the effect of selected resource
            Resources r;
            r.setSType(LResource->getData(i));
            r.setSize();
            r.setRepChar();
            r.setBoardSRep();
            r.setEffect(W1);
        }
       
        for (int i = 0; i < ListSize; i++) {
            Zombies z;
            z.setType(LZombie->getData(i));       //sets the zombie type by getting the linked list data, which represents the zombie type, in order
            ListDerick.AddNode(z.getType());       //adds the zombie to the linked list
            z.setDamagePerHit();
            z.setForBoard();
            z.setLife();
            z.setRepChar();
            z.setScorePerItem();
            z.setSize();

            while (finish != 1) {
                diceVal = (rand() % 6) + 1;
                cout << "Dice value is: " << diceVal << endl;
                cout << "Derick attacks!" << endl;
                if (D.getAmmunition() == 0) {
                    z.updateLife(0);       //This 0 value represents that Derick will use his knife for the zombie so dice value will be invalid in this case
                }
                else if (D.getAmmunition() == 1) {
                    D.updateAmmunition(1, 0);       //Derick attacks. Update the ammunition used
                    z.updateLife(diceVal);     //zombie's life is reduced
                //    cout << "Life of zombie is: " << z1.getLife();
                //    cout << "Life of Derick is: " << D.getLife();
                }
                else {
                    D.updateAmmunition(2, 0);       //Derick attacks. Updates the ammunition used
                    z.updateLife(diceVal);     //zombie's life is reduced twice as Derick shoots 2 salvos
                    z.updateLife(diceVal);
                    //   cout << "Life of zombie is: " << z1.getLife();
                    //   cout << "Life of Derick is: " << D.getLife();
                }

                if (D.isLost()) {
                    cout << "Derick lost!\n\ The zombie won!" << endl;
                    finish = 1;
                    break;
                }
                else if (z.isDead()) {
                    cout << "Zombie lost!\n\ Derick won!" << endl;
                    finish = 1;
                    break;
                }

                cout << "Zombie attacks!" << endl;
                D.updateLife(z.getDamagePerHit(), 0);      //If both are alive, then zombie's turn to attack. Derick's life will be reduced by the amount of the damage per hit of the zombie

                //Checks again if both are alive or not. If they are, then continue for the next round until one of them die
                if (D.isLost()) {
                    cout << "Derick lost!\n\ The zombie won!" << endl;
                    finish = 1;
                    break;
                }
                else if (z.isDead()) {
                    cout << "Zombie lost!\n\ Derick won!" << endl;
                    finish = 1;
                    break;
                }
            }

        }   
        cout << "Player-1 (Derick) killed: ";
        ListDerick.print();
        cout << "Total score: " << ListDerick.TotalScore();     //prints total score of Derick
        break;

    case 2:
        //Chichonne is playing

        for (int i = 0; i < sizeResource; i++) {        //makes necessary changes according to the effect of selected resource
            Resources r;
            r.setSType(LResource->getData(i));
            r.setSize();
            r.setRepChar();
            r.setBoardSRep();
            r.setEffect(W2);
        }

        for (int i = 0; i < ListSize; i++) {
            Zombies z;
            z.setType(LZombie->getData(i));       //sets the zombie type by getting the linked list data, which represents the zombie type, in order
            ListChichonne.AddNode(z.getType());       //adds the zombie to the linked list
            z.setDamagePerHit();
            z.setForBoard();
            z.setLife();
            z.setRepChar();
            z.setScorePerItem();
            z.setSize();

            while (finish != 1) {
                diceVal = (rand() % 6) + 1;
                cout << "Dice value is: " << diceVal << endl;
                cout << "Chichonne attacks!" << endl;
                if (C.getAmmunition() == 0) {
                    if (counter == 2)
                        z.updateLife(-2);      //Her katana levels up to mega-katana 
                    else
                        z.updateLife(-1);       //She will use her katana for the zombie so dice value will be invalid in this case
                    counter++;
                }
                else {
                    C.updateAmmunition(1, 0);       //Chichonne attacks. Update the ammunition used
                    z.updateLife(diceVal);     //zombie's life is reduced
                //    cout << "Life of zombie is: " << z1.getLife();
                //    cout << "Life of Chichonne is: " << C.getLife();
                }

                if (C.isLost()) {
                    cout << "Chichonne lost!\n\ The zombie won!" << endl;
                    finish = 1;
                    break;
                }
                else if (z.isDead()) {
                    cout << "Zombie lost!\n\ Chichonne won!" << endl;
                    finish = 1;
                    break;
                }

                cout << "Zombie attacks!" << endl;
                C.updateLife(z.getDamagePerHit(), 0);      //If both are alive, then zombie's turn to attack. Chichonne's life will be reduced by the amount of the damage per hit of the zombie

                //Checks again if both are alive or not. If they are, then continue for the next round until one of them die
                if (C.isLost()) {
                    cout << "Chichonne lost!\n\ The zombie won!" << endl;
                    finish = 1;
                    break;
                }
                else if (z.isDead()) {
                    cout << "Zombie lost!\n\ Chichonne won!" << endl;
                    finish = 1;
                    break;
                }
            }
        }
        cout << "Player-2 (Chichonne) killed: ";
        ListChichonne.print();
        cout << "Total score: " << ListChichonne.TotalScore();      //prints total score of Chichonne
        break;
    default:
        cout << "Invalid choice!\n";
        break;
    }
}

int main()
{
    srand(time(0));

    Grid grid;
    grid.setgridsize();
    grid.setgrid();     //creates the grid
   
    grid.updategrid();      //updates the grid according to the changes 
   
    LinkedList* L1, *L2;  //This representation is just not to get errors for the Battle function inputs. (They will actually come from the Grid function as an output)
                          //L1 and L2 will come from the Grid function and they will represent zombie linked list and/or resource 
                          //linked list after randomly getting the types for both.           
    Battle(L1, L2);
}


