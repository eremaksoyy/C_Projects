#include "Derick.h"

Derick::Derick()
{
    Knife = 1;
    this->setAmmunition(30);
    this->setLife(100);
}
