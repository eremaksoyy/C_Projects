#pragma once
#include "Warrior.h"

class Derick:public Warrior
{
private:
	int Knife;

public:
	Derick();
	
};

