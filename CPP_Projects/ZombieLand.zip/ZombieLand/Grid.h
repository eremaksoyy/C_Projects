#pragma once
#include <iostream>
#include "Entity.h"
#include "Resources.h"
#include "Zombies.h"

struct TwoDimGrid
{
    Resources resources;
    Zombies zombies;
};

class Grid
{
private:
    int gridsize;
    Resources resource;
    Zombies zombies;
    TwoDimGrid** grid;

public:
    Grid();
    ~Grid();
    void setgrid();
    TwoDimGrid** getgrid();
    void setgridsize();
    int getgridsize();
    void updategrid();
    void printGrid(struct TwoDimGrid**, int, int);
    int RandomGenerator(int n);
    struct TwoDimGrid** Deploy_Function();//creates two dimentional structure array as grid
};

