#include "Chichonne.h"

Chichonne::Chichonne()
{
    Katana = 4;
    this->setAmmunition(25);
    this->setLife(100);
}
