#include <iostream>
#include "LinkedList.h"

using std::cout;

LinkedList::LinkedList() {
	head = NULL;
	tail = NULL;
}

void LinkedList::AddNode(int num) {		//takes the type of the zombie as a num (the number from its enum representation) and insert it to the linked list
	Node* tmp = new Node;
	tmp->data = num;
	tmp->next = NULL;

	if (head == NULL)
	{
		head = tmp;
		tail = tmp;
	}
	else
	{
		tail->next = tmp;
		tail = tail->next;
	}
}

int LinkedList::getData(int stop) {
	int counter = 0;
	Node* newNode = new Node;
	newNode->next = NULL;
	newNode = this->head;
	while (newNode != NULL) {
		if (counter == stop)
			return newNode->data;
		newNode = newNode->next;
		counter++;
	}
}

Node* LinkedList::getHead() {
	return this->head;
}

Node* LinkedList::getTail() {
	return this->tail;
}

int LinkedList::getLength() {
	int counter = 0;
	Node* newNode = new Node;
	newNode->next = NULL;
	newNode = this->head;
	while (newNode != NULL) {
		newNode = newNode->next;
		counter++;
	}
	return counter;
}

void LinkedList::contentPrint(Node* N) {		//takes the type of a zombie as a number from the enum representation
	if (N->data == 0)
		cout << "Large Zombie";
	else if (N->data == 1)
		cout << "Medium Zombie";
	else
		cout << "Small Zombie";
}

void LinkedList::print() {		//prints the content of the linked list
	Node* newList = new Node;
	newList->next = NULL;
	newList = this->head;
	while (newList != NULL) {
		contentPrint(newList);
		newList = newList->next;
		if (newList != NULL)
			cout << ",";
	}
}

int LinkedList::decideScore(int T) {
	if (T == 0)
		return 100;
	else if (T == 1)
		return 75;
	else
		return 50;
}

int LinkedList::TotalScore() {
	int totalScore = 0;
	Node* newNode = new Node;
	newNode->next = NULL;
	newNode = this->head;
	while (newNode != NULL) {
		newNode = newNode->next;
		totalScore += this->decideScore(newNode->data);
	}
	return totalScore;
}
