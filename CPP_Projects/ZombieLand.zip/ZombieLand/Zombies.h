#pragma once
#include "Entity.h"

enum type { LargeZombie, MediumZombie, SmallZombie };
enum boardRep { L, M, S };
class Zombies :public Entity {
private:
	enum type Type;
	int life;
	int DamagePerHit;
	enum boardRep forBoard;
	int ScorePerItem;
	int Check;		//added for grid function by student 1
	int Isdeleted;	//added for grid function by student 1

public:
	void setSize();		//sets the size according to the type of zombie
	void setRepChar();
	void setType(int);		//sets the type according to the random value gotten
	void setLife();
	void setDamagePerHit();
	void setForBoard();
	void setScorePerItem();
	int getSize();
	char* getRepChar();
	int getType();
	int getLife();
	int getDamagePerHit();
	int getForBoard();
	int getScorePerItem();
	void updateLife(int);
	bool isDead();
	void setCheck(int x);		//added for grid function by student 1
	int getCheck();		//added for grid function by student 1
	void DeleteRepChar();		//added for grid function by student 1
	void setIsdeleted(int x);	//added for grid function by student 1
	int getIsdeleted();		//added for grid function by student 1
};

