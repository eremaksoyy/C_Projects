#pragma once
#include "Warrior.h"

class Chichonne:public Warrior
{
private:
	int Katana;

public:
	Chichonne();
    
};

