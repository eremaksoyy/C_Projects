#pragma once
#include "Entity.h"
#include "Warrior.h"

enum resource { LargeMedKit, SmallMedKit, Ammunition };
class Resources :public Entity {
private:
	enum resource SType;
	int effect;
	char* BoardSRep;
	int Check;		//added for grid function by student 1
	int Isdeleted;	//added for grid function by student 1

public:
	~Resources();
	void setSize();		//sets the size by considering the type of resource
	void setRepChar();
	void setSType(int);
	void setEffect(Warrior*);
	void setBoardSRep();
	int getSize();
	char* getRepChar();
	int getSType();
	char* getBoardSRep();
	void setCheck(int x);	//added for grid function by student 1
	int getCheck();		//added for grid function by student 1
	void DeleteRepChar();		//added for grid function by student 1
	void setIsdeleted(int x);	//added for grid function by student 1
	int getIsdeleted();		//added for grid function by student 1
};



