#include "Zombies.h"

void Zombies::setSize() {
	if (Type == LargeZombie)
		size = 3;
	else if (Type == MediumZombie)
		size = 2;
	else
		size = 1;
}

void Zombies::setRepChar() {
	this->RepChar = new char[2];
	strcpy(RepChar, "Z");
}

void Zombies::setType(int num) {
	if (num == 0)
		this->Type = LargeZombie;
	else if (num == 1)
		this->Type = MediumZombie;
	else
		this->Type = SmallZombie;
}

void Zombies::setLife() {
	if (this->getType() == 0)
		this->life = 12;
	else if (this->getType() == 1)
		this->life = 8;
	else
		this->life = 4;
}

void Zombies::setDamagePerHit() {
	if (this->getType() == 0)
		this->DamagePerHit = 8;
	else if (this->getType() == 1)
		this->DamagePerHit = 4;
	else
		this->DamagePerHit = 2;
}

void Zombies::setForBoard() {
	if (this->getType() == 0)
		this->forBoard = L;
	else if (this->getType() == 1)
		this->forBoard = M;
	else
		this->forBoard = S;
}

void Zombies::setScorePerItem() {
	if (this->getType() == 0)
		this->ScorePerItem = 100;
	else if (this->getType() == 1)
		this->ScorePerItem = 75;
	else
		this->ScorePerItem = 50;
}

int Zombies::getSize() {
	return this->size;
}

char* Zombies::getRepChar() {
	return this->RepChar;
}

int Zombies::getType() {
	return this->Type;
}

int Zombies::getLife() {
	return this->life;
}

int Zombies::getDamagePerHit() {
	return this->DamagePerHit;
}

int Zombies::getForBoard() {
	return this->forBoard;
}

int Zombies::getScorePerItem() {
	return ScorePerItem;
}

void Zombies::updateLife(int diceVal) {
	if (diceVal >= 5)
		life -= 10;
	else if (diceVal <= 2)
		life -= 2;
	else if (diceVal == 0)		//This value is not dice value. 0 will be sent here when Derick uses his knife
		life -= 1;
	else if (diceVal == (-1))		// (-1) value will be sent here when Chichonne uses her katana
		life -= 4;
	else if (diceVal == (-2))		// (-2) value will  be sent here when Chichonne uses her mega-katana
		life -= 6;
	else
		life -= 5;
}

bool Zombies::isDead() {
	if (this->getLife() <= 0)
		return 1;
	else
		return 0;
}

void Zombies::setCheck(int x)
{
	this->Check = x;
}

int Zombies::getCheck()
{
	return this->Check;
}

void Zombies::DeleteRepChar() {
	this->RepChar = new char[2];
	strcpy(RepChar, "x");
}

void Zombies::setIsdeleted(int x)
{
	this->Isdeleted = x;
}

int Zombies::getIsdeleted()
{
	return this->Isdeleted;
}
