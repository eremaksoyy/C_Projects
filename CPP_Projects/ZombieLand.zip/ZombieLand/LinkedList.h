#pragma once
struct Node {
	int data;
	struct Node* next;
};

class LinkedList {		//linked list class to hold zombies for the warriors
private:
	Node* head;
	Node* tail;

public:
	LinkedList();
	void AddNode(int);
	int getData(int);		//gives the data of the desired node of the linked list 
	Node* getHead();
	Node* getTail();
	int getLength();
	void contentPrint(Node*);
	void print();		//prints the content of the linked list
	int decideScore(int);		//helper function for the totalscore function
	int TotalScore();		//gives the total score of the warrior according to the zombies they killed 
};