#pragma once
#include "Entity.h"

class Warrior:public Entity
{
protected:
	int Life;
	int ammunition;

public:
    Warrior();
    void setSize();
    void setRepChar();
    void setAmmunition(int);
    void setLife(int);
    int getAmmunition();
    int getLife();
    void updateLife(int attack, int LifePoints);        //updates life points due to attacks(integer) and LifePoints
    void updateAmmunition(int shoot, int AmmunitionPoints);     //takes number of shoots and AmmunitionPoints calculates remaining ammunition and adds extra ammunitions
    bool isLost();      //checks if life points are zero or not
    bool isOutofAmmunition();       //checks if warrior out of ammunition or not
};

