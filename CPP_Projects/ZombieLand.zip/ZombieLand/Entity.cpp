#include <iostream>
#include "Entity.h"

using std::cout;
using std::endl;

Entity::Entity() {
	size = 0; 
	RepChar = NULL;
}

Entity::~Entity() {
	delete []  RepChar;
}
 