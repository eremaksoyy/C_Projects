#include <iostream>
#include "Warrior.h"

using std::cout;

Warrior::Warrior()
{
    Life = 0;
    ammunition = 0;
}

void Warrior::setSize() {
        size = 1;
}

void Warrior::setRepChar() {
    strcpy(RepChar, "W");
}

void Warrior::setLife(int life)
{
    this->Life = life;
}

int Warrior::getLife()
{
    return this->Life;
}

void Warrior::setAmmunition(int a)
{
    this->ammunition = a;
}

int Warrior::getAmmunition()
{
    return this->ammunition;
}


void Warrior::updateLife(int attack, int LifePoints)
{
    this->Life = this->Life + LifePoints;
    this->Life = this->Life - attack;
}


bool Warrior::isLost()
{
    if ((getLife()) <= 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}


void Warrior::updateAmmunition(int shoot, int AmmunitionPoints)
{

    if (shoot == 1)
    {
        this->ammunition = this->ammunition - 1;
    }
    else if (shoot == 2)
    {
        this->ammunition = this->ammunition - 2;
    }

    this->ammunition = this->ammunition + AmmunitionPoints;

}

bool Warrior::isOutofAmmunition()
{

    if ((getAmmunition()) == 0)
    {
        return 1;
    }
    else
    {
        return 0;
    }
}



