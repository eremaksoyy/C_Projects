#pragma once
#include <iostream>

class Entity
{
protected:
	int size;
	char* RepChar;

public:
	Entity();
	~Entity();
	virtual void setSize() = 0;
	virtual void setRepChar() = 0;
};

