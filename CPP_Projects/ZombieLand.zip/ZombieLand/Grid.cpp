#include <iostream>
#include <cstring>
#include "Grid.h"
#include "Resources.h"
#include "LinkedList.h"
#include "Zombies.h"
#include "Entity.h"

using std::cin;
using std::cout;
using std::string;

Grid::Grid()
{
    gridsize = 0;
    grid = NULL; 
}

Grid::~Grid() {
    delete[] grid;
}

void Grid::setgrid()
{
    this->grid = this->Deploy_Function();
}

TwoDimGrid** Grid::getgrid() {
    return this->grid;
}

void Grid::setgridsize()
{
    int size;
    printf("\nPlease enter the board size :  ");
    cin >> size;
    while (size < 5)
    {
        printf("\nPlease enter the board size :  ");
        cin >> size;
    }
    this->gridsize = size;
}

int Grid::getgridsize()
{
    return this->gridsize;
}

void Grid::updategrid()
{
    int x;
    int y;
    TwoDimGrid** grid = getgrid();
    printf("\nPlease enter x coordinate :");
    cin >> x;
    printf("\nPlease enter x coordinate :");
    cin >> y;
    
    if (grid[x][y].resources.getCheck() == 1)
    {
        grid[x][y].resources.DeleteRepChar();   //this part deletes the resources if that square is chosen by the user
    }
    if (grid[x][y].zombies.getCheck() == 1)
    {
        grid[x][y].zombies.DeleteRepChar();
    }
    printGrid(grid, x, y);
}

void Grid::printGrid(TwoDimGrid** grid, int x, int y)
{
    int n = getgridsize();
    int i = 0;
    int j = 0;

    printf("\n");
    while (i < n)
    {
        j = 0;
        while (j < n)
        {
            if (grid[i][j].zombies.getCheck() == 1)
            {
                printf("%s", grid[i][j].zombies.getRepChar());
            }
            else
            {
                printf("?");
            }

            j++;
        }
        printf("\n");
        i++;
    }

    i = 0;
    j = 0;
    printf("\n");

    while (i < n)
    {
        j = 0;
        while (j < n)
        {
            if (grid[i][j].resources.getCheck() == 1)
            {
                printf("%s", grid[i][j].resources.getRepChar());
            }
            else
            {
                printf("?");
            }

            j++;
        }
        printf("\n");
        i++;
    }
}

int Grid::RandomGenerator(int n)
{
    int randValue;
    randValue = rand() % n;
    return randValue;
}

struct TwoDimGrid** Grid::Deploy_Function()
{
    int n;//this is the value of one side of the board
    n = getgridsize();
    TwoDimGrid** grid;
    grid = (TwoDimGrid**)malloc(sizeof(TwoDimGrid*) * n);
    for (int c = 0; c < n; c++) {
        grid[c] = (TwoDimGrid*)malloc(sizeof(TwoDimGrid) * n);
    }

    int numZombies = 2 * ((n * n) / 25);//calculates how many zombies should be in the board due to size
    int numMedicinekit = 3 * ((n * n) / 25);
    int numAmmunition = 2 * ((n * n) / 25);
    int counter = 0;
    int x;     //x and y are the coordinates
    int y;
    int randomzombie;
    LinkedList ZombieList;
    LinkedList ResourcesList;

    while (counter < numZombies)
    {
        randomzombie = RandomGenerator(3);
        x = RandomGenerator(n);
        y = RandomGenerator(n);
        grid[x][y].zombies.setRepChar();
        grid[x][y].zombies.setCheck(1);
        grid[x][y].zombies.setType(randomzombie);
        grid[x][y].zombies.setSize();
        grid[x][y].zombies.setLife();
        grid[x][y].zombies.setDamagePerHit();
        grid[x][y].zombies.setForBoard();
        grid[x][y].zombies.setScorePerItem();
        ZombieList.AddNode(randomzombie);

        counter++;
    }
    //ZombieList.print();

    counter = 0;

    while (counter < numMedicinekit)
    {
        int randomMedicineKit = RandomGenerator(2);
        x = RandomGenerator(n);
        y = RandomGenerator(n);
        grid[x][y].resources.setCheck(1);
        grid[x][y].resources.setRepChar();
        grid[x][y].resources.setSType(randomMedicineKit);
        grid[x][y].resources.setSize();
        grid[x][y].resources.setBoardSRep();
        ResourcesList.AddNode(randomMedicineKit);
        //grid[x][y].resources.setEffect();
        counter++;
    }
    counter = 0;
    //MedicineKitList.print();


    while (counter < numAmmunition)
    {
        x = RandomGenerator(n);
        y = RandomGenerator(n);
        grid[x][y].resources.setCheck(1);
        grid[x][y].resources.setSize();
        grid[x][y].resources.setRepChar();
        grid[x][y].resources.setSType(3);
        grid[x][y].resources.setBoardSRep();
        ResourcesList.AddNode(3);
        //grid[x][y].resources.setEffect();
        counter++;
    }
    counter = 0;

    return grid;
}
