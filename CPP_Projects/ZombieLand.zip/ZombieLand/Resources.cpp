#include "Resources.h"

Resources::~Resources() {
	delete [] BoardSRep;
}

void Resources::setSize() {
	if (SType == LargeMedKit)
		size = 2;
	else
		size = 1;
}

void Resources::setRepChar() {
	strcpy(RepChar, "R");
}

void Resources::setSType(int val) {
	if (val == 0)
		this->SType = LargeMedKit;
	else if (val == 1)
		this->SType = SmallMedKit;
	else
		this->SType = Ammunition;
}

void Resources::setEffect(Warrior* W) {
	if (this->getSType() == 0)
		W->updateLife(0, 20);
	else if (this->getSType() == 1)
		W->updateLife(0, 10);
	else
		W->updateAmmunition(0, 10); 
}

void Resources::setBoardSRep() {
	if (this->getSType() == 0)
		strcpy(this->BoardSRep, "*");
	else if (this->getSType() == 1)
		strcpy(this->BoardSRep, "+");
	else
		strcpy(this->BoardSRep, "A");
}

int Resources::getSize() {
	return this->size;
}

char* Resources::getRepChar() {
	return this->RepChar;
}

int Resources::getSType() {
	return this->SType;
}

char* Resources::getBoardSRep() {
	return this->BoardSRep;
}

void Resources::setCheck(int x)
{
	this->Check = x;
}

int Resources::getCheck()
{
	return this->Check;
}

void Resources::DeleteRepChar() {
	this->RepChar = new char[2];
	strcpy(RepChar, "x");
}

void Resources::setIsdeleted(int x)
{
	this->Isdeleted = x;
}

int Resources::getIsdeleted()
{
	return this->Isdeleted;
}