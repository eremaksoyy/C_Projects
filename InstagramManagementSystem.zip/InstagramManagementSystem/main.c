
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#define MAX_SIZE_FILE 10000
#define MAX_ID 5
#define SIZE 25

struct Current_Time {
	int hour ;
	int min ;
	};

struct Current_Date {
	int day ;
	int month ;
	int year ;
	};

struct Info	{
	struct Current_Date *Date ;
	struct Current_Time *Time ;
	};

typedef struct node	{
	int id_number ;
	char acc_name[SIZE] ;
	int no_of_posts ;
	int no_of_following ;
	int no_of_followers ;
	struct Info *date_time ;
	struct node *next ;
	} Node ;

typedef struct ListRecord	{
	struct node *head ;
	struct node *tail ;
	int size ;
	} List ;

List *initialiseMyAccount(char *) ;
void addAccount(List *, char *, int, int, int) ;
void printMyAccount(List *) ;
void searchAccount(List *, char *) ;
void deleteAccount(List *, int) ;
void overwriteMyAccount(List *, char *) ;
void makeEmptyList(List *) ;
void user_choice(char *) ;

int main()
{
	int option ;
	char *file1 = "following.txt", *file2 = "followers.txt" ;
	List *following_accounts ;		//Decleration of linked list for following's accounts.
	following_accounts = (List *)malloc(sizeof(List)) ;
	if(following_accounts->head == NULL)	{
		printf("Creation of following accounts list is not successful!\n ") ;
		exit(1) ;	}
	else
		following_accounts = initialiseMyAccount(file1) ;

	List *followers_accounts ;		//Decleration of linked list for follower's accounts.
	followers_accounts = (List *)malloc(sizeof(List)) ;
	if(followers_accounts->head == NULL)	{
		printf("Creation of followers account list is not successful! ") ;
		exit(2) ;	}
	else
		followers_accounts = initialiseMyAccount(file2) ;
	if(following_accounts->head->next!=NULL && followers_accounts->head->next!=NULL)	//Check if both file have been loaded successfully.
		printf("The %s file has been loaded successfully\nThe %s file has been loaded successfully\n\n ", file1, file2) ;
	else
		printf("%s and %s couldn't be loaded successfully! \n\n", file1, file2) ;
	do {
		int option_file, post, follower, following, id ;
		char accountName[SIZE], name[SIZE] ;
		printf("------ MENU ------ \n") ;
		printf("1. Add a new Account\n2. Print My Account Info\n3. Search Account\n4. Delete Account\n5. Exit\n\nEnter your option:  ") ;
		scanf("%d", &option) ;
		switch(option)	{
			case 1:
				printf("(1) Add a following account\n(2) Add a follower account\nEnter your option: ") ;
				scanf("%d", &option_file) ;
				fflush(stdin) ;
				printf("Enter name of the account: ") ;
				gets(name) ;
				printf("Enter number of posts: ") ;
				scanf("%d", &post) ;
				fflush(stdin) ;
				printf("Enter number of following: ") ;
				scanf("%d", &following) ;
				fflush(stdin) ;
				printf("Enter number of followers: ") ;
				scanf("%d", &follower) ;
				fflush(stdin) ;
				if(option_file == 1)	{
					addAccount(following_accounts,name,post,following,follower) ;
					if(following_accounts != NULL)
						printf("The account has been added to following list!! \n\n") ;	}
				else if(option_file == 2)	{
					addAccount(followers_accounts,name,post,following,follower)	;
					if(followers_accounts != NULL)
						printf("The account has been added to followers list!! \n\n") ;	}
				break;
			case 2:
				user_choice("Print") ;
				scanf("%d", &option_file) ;
				if(option_file == 1)	{
					printf("\n\n------ My Following List ------\n") ;
					printMyAccount(following_accounts) ;	}
				else if(option_file == 2)	{
					printf("\n\n------ My Followers List ------\n") ;
					printMyAccount(followers_accounts) ;	}
				else
					printf("You entered an invalid value! \n\n") ;
				break;
			case 3:
				user_choice("Search") ;
				scanf("%d", &option_file) ;
				fflush(stdin) ;
				printf("Enter Account name: ") ;
				gets(accountName) ;
				if(option_file == 1)
					searchAccount(following_accounts,accountName) ;
				else if(option_file == 2)
					searchAccount(followers_accounts,accountName) ;
				else
					printf("You entered an invalid value! \n\n") ;
				break;
			case 4:
				printf("(1) Delete account from following list\n(2) Delete account from follower list\nEnter your option: ") ;
				scanf("%d", &option_file) ;
				fflush(stdin) ;
				printf("Enter account ID: ") ;
				scanf("%d", &id) ;
				fflush(stdin) ;
				if(option_file == 1)
					deleteAccount(following_accounts,id) ;
				else if(option_file == 2)
					deleteAccount(followers_accounts,id) ;
				else
					printf("You entered an invalid value! \n\n") ;
				break;
			case 5:
				printf("Goodbye!!\n\n") ;
				overwriteMyAccount(following_accounts,file1) ;
				overwriteMyAccount(followers_accounts,file2) ;
				exit(1) ;
			}
		}while((option>0) && (option<6));
	printf("You entered an invalid value! \n") ;
	return 0 ;
}

List *initialiseMyAccount(char *file_name)		//This function takes the file name and creates a linked list for the accounts inside the file.
{
	char day_array[SIZE], month_array[SIZE], year_array[SIZE], hour_array[SIZE], min_array[SIZE] ;
	char array[MAX_SIZE_FILE], *token, *holder_date, *holder_time ;
	char id[MAX_ID], account_name[SIZE], post[MAX_SIZE_FILE], following[MAX_SIZE_FILE], followers[MAX_SIZE_FILE], date_array[SIZE], time_array[SIZE] ;	//variables used for holding the data from the file.
	List *L;
	Node *tmp ;
	L = (List *)malloc(sizeof(List)) ;
	if(L == NULL)	{
		printf("Creation of linked list is not successful!\n ") ;
		exit(1) ;	}
	else	{
		L->head = (Node *)malloc(sizeof(Node)) ;
		if(L->head == NULL)	{
			printf("Creation of linked list is not successful!\n ") ;
			exit(1) ;	}
		else	{
			makeEmptyList(L) ;   }	}
	FILE *inFile ;
    inFile = fopen(file_name, "r") ;		//Opens the file for reading the data inside it to create necessary linked lists.
    if(inFile == NULL)	{
        printf("Opening %s file is not successful! ",file_name);
        exit(1) ;	}
    while(fgets(array, MAX_SIZE_FILE, inFile) != NULL)	{
		token = strtok(array, ";") ;
		while(token != NULL){
			strcpy(id, token) ;
			strcpy(account_name, strtok(NULL, ";")) ;
			strcpy(post, strtok(NULL, ";")) ;
			strcpy(following, strtok(NULL, ";")) ;
			strcpy(followers, strtok(NULL, ";")) ;
			strcpy(date_array, strtok(NULL, ";")) ;
			strcpy(time_array, strtok(NULL, ";")) ;
			token= strtok(NULL, ";"); }
			tmp = (Node *)malloc(sizeof(Node )) ;
			tmp->date_time = (struct Info *)malloc(sizeof(struct Info)) ;
			tmp->date_time->Date = (struct Current_Date *)malloc(sizeof(struct Current_Date )) ;
			tmp->date_time->Time = (struct Current_Time *)malloc(sizeof(struct Current_Time ));
			if(tmp == NULL)	{
				printf("Creation of linked list is not successful!\n ") ;
				exit(1) ;	}
			tmp->id_number = atoi(id) ;
		    strcpy(tmp->acc_name, account_name) ;
			tmp->no_of_posts = atoi(post) ;
			tmp->no_of_following =  atoi(following) ;
			tmp->no_of_followers =  atoi(followers) ;


			holder_date = strtok(time_array,"/") ;

			while(holder_date != NULL)	{
				strcpy(day_array,holder_date) ;
				strcpy(month_array,strtok(NULL,"/")) ;
				strcpy(year_array,strtok(NULL,"/")) ;
				strcpy(year_array,strtok(year_array," "));
				holder_date = strtok(NULL,"/");
				strcpy(time_array,holder_date);
				holder_date=NULL;
				tmp->date_time->Date->day = atoi(day_array) ;
				tmp->date_time->Date->month = atoi(month_array) ;
				tmp->date_time->Date->year = atoi(year_array) ;	}
			holder_time = strtok(time_array, ":") ;
			while(holder_time != NULL)	{
				strcpy(hour_array, holder_time) ;
				strcpy(min_array, strtok(NULL, ":")) ;
				holder_time = strtok(NULL, ":");
				tmp->date_time->Time->hour = atoi(hour_array) ;
				tmp->date_time->Time->min = atoi(min_array) ;	}
			tmp->next = NULL ;
			L->size++ ;
			if(L->head == NULL)	{
				L->head->next = tmp ;
				L->head = L->tail = tmp ;	}
			else	{
				L->tail->next = tmp ;
				L->tail = tmp ;	}	}
	fclose(inFile) ;
	return L ;
}

void addAccount(List *L, char *accountName, int postNo, int followingNo, int followersNo)	//This function add a new account at the end of the linked list with entered informations by user.
{
	int id;
	time_t ti = time(NULL);
	struct tm local = *localtime(&ti);	//Takes the current date and time to insert them into the newly created node.
	Node *tmp ;
	id = L->tail->id_number ;
	if(L->head->next != NULL)	{
		tmp = (Node *)malloc(sizeof(Node )) ;
		tmp->date_time = (struct Info *)malloc(sizeof(struct Info)) ;
		tmp->date_time->Date = (struct Current_Date *)malloc(sizeof(struct Current_Date )) ;
		tmp->date_time->Time = (struct Current_Time *)malloc(sizeof(struct Current_Time ));
		if(tmp->next == NULL)	{
			printf("Creation of linked list is not successful!\n ") ;
			exit(1) ;	}
		tmp = L->head ;
		while(tmp->next!=NULL && strcmp(tmp->next->acc_name,accountName)!=0)	{
			tmp = tmp->next ;	}
		if(tmp->next!=NULL){
			printf("\nThe account already exists!!! \n") ;
			exit(1) ;	}
		else	{
			tmp->next = (Node *)malloc(sizeof(Node )) ;
			tmp->next->date_time = (struct Info *)malloc(sizeof(struct Info)) ;
			tmp->next->date_time->Date = (struct Current_Date *)malloc(sizeof(struct Current_Date )) ;
			tmp->next->date_time->Time = (struct Current_Time *)malloc(sizeof(struct Current_Time ));
			tmp= tmp->next ;
			tmp->id_number = id+1 ;
			if(sizeof(tmp->id_number)> 5)	{
				printf("ID cannot have more than 5 digits! \n") ;
				exit(1) ;	}
			tmp->no_of_posts = postNo ;
			tmp->no_of_following = followingNo ;
			tmp->no_of_followers = followersNo ;
			strcpy(tmp->acc_name,accountName) ;
			tmp->date_time->Date->day = local.tm_mday ;
			tmp->date_time->Date->month = local.tm_mon+1 ;
			tmp->date_time->Date->year = local.tm_year+1900 ;
			tmp->date_time->Time->hour = local.tm_hour ;
			tmp->date_time->Time->min = local.tm_min ;
			tmp->next = NULL ;
			L->tail->next = tmp ;
			L->tail = tmp ;
			L->size ++ ;	}	}
}

void printMyAccount(List *L)	//This function prints the linked list chosen by user.
{
	Node *new_list ;
	new_list = (Node *)malloc(sizeof(Node )) ;
	if(new_list->next == NULL)	{
		printf("Creation of linked list is not successful!\n ") ;
		exit(1) ;}
	else
		new_list = L->head ;
	while(new_list->next!=NULL)	{
		new_list = new_list->next ;
		printf("Account ID: %d \n", new_list->id_number) ;
		printf("Account name: %s \n", new_list->acc_name) ;
		printf("Number of posts: %d \n", new_list->no_of_posts) ;
		printf("Number of following: %d \n", new_list->no_of_following) ;
		printf("Number of followers: %d \n", new_list->no_of_followers) ;
		printf("Date: %.2d/%.2d/%d \n", new_list->date_time->Date->day, new_list->date_time->Date->month, new_list->date_time->Date->year) ;
		printf("Time: %.2d:%.2d \n", new_list->date_time->Time->hour, new_list->date_time->Time->min) ;
		printf("*********************************\n") ;	}
	printf("\n") ;
}

void searchAccount(List *L, char *accountName)	//This function searches for a specific account by using the account name.
{
	int counter=0 ;
	Node *tmp ;
	if(L->head->next != NULL)	{
		tmp = (Node *)malloc(sizeof(Node )) ;
		tmp->date_time = (struct Info *)malloc(sizeof(struct Info)) ;
		tmp->date_time->Date = (struct Current_Date *)malloc(sizeof(struct Current_Date )) ;
		tmp->date_time->Time = (struct Current_Time *)malloc(sizeof(struct Current_Time ));
		if(tmp->next == NULL)	{
			printf("Creation of linked list is not successful!\n ") ;
			exit(1) ;	}
		tmp = L->head ;
		while(tmp->next!=NULL)	{
			tmp = tmp->next ;
			if(strcmp(tmp->acc_name,accountName) == 0)	{
				counter ++	;
				printf("\nAccount ID: %d \n", tmp->id_number) ;
				printf("Account name: %s \n", tmp->acc_name) ;
				printf("Number of posts: %d \n", tmp->no_of_posts) ;
				printf("Number of following: %d \n", tmp->no_of_following) ;
				printf("Number of followers: %d \n", tmp->no_of_followers) ;
				printf("Date: %.2d/%.2d/%d \n", tmp->date_time->Date->day, tmp->date_time->Date->month, tmp->date_time->Date->year) ;
				printf("Time: %.2d:%.2d \n", tmp->date_time->Time->hour, tmp->date_time->Time->min) ;	}	}	}
	printf("\n") ;
	if(counter==0)	{
		printf("There is no account with this name in the list!!!! \n\n") ;	}
}

void deleteAccount(List *L, int id)		//This function deletes an account by taking the id of the account from the user.
{
	if(L != NULL)	{
		Node *temp ;
		temp = (Node *)malloc(sizeof(Node )) ;
		temp->date_time = (struct Info *)malloc(sizeof(struct Info)) ;
		temp->date_time->Date = (struct Current_Date *)malloc(sizeof(struct Current_Date )) ;
		temp->date_time->Time = (struct Current_Time *)malloc(sizeof(struct Current_Time ));
		if(temp->next == NULL)	{
			printf("Creation of linked list is not successful!\n ") ;
			exit(1) ;	}
		temp = L->head ;
		while(temp->next!=NULL && temp->next->id_number!=id)	{
			temp = temp->next ; }
		if(temp->next == NULL)
			printf("\nAccount with ID %d does not exist.\n\n", id) ;
		else {
			Node *deleted_id ;
			deleted_id = (Node *)malloc(sizeof(Node )) ;
			deleted_id = temp->next ;
			temp->next = temp->next->next ;
			free(deleted_id) ;
			printf("\nAccount with ID %d has been deleted successfully!\n\n", id) ;	}	}
}

void overwriteMyAccount(List *L, char *file_name)		//THis function overwrites both file with the updated data.
{
	FILE *inFile ;
	inFile = fopen(file_name, "w+") ;
	while(L->head->next != NULL)	{
		L->head = L->head->next ;
		fprintf(inFile, "%d;%s;%d;%d;%d;%d;", L->head->id_number, L->head->acc_name, L->head->no_of_posts, L->head->no_of_following, L->head->no_of_followers) ;
		fprintf(inFile, "%.2d/%.2d/%.2d ", L->head->date_time->Date->day, L->head->date_time->Date->month, L->head->date_time->Date->year) ;
		fprintf(inFile, "%.2d:%.2d\n", L->head->date_time->Time->hour, L->head->date_time->Time->min) ;	}
}

void makeEmptyList(List *L)		//This functin makes the empty list for linked lists.
{
		L->head->next = NULL ;
		L->tail = L->head ;
		L->size = 0 ;
}

void user_choice(char *name)		//This function asks the user which list(following/followers) s/he wants to reach the data for according to the operation.
{
	printf("(1) %s following list\n(2) %s follower list\n", name, name) ;
	printf("Enter your option:  ") ;
}


