
This C program is a Quiz Game where 10 questions are being read from a .txt file and an array is created accordingly.
As the array is created dynamically, more questions can be added to the file as well, program would still work as fine.

The user is asked to select an option from the menu displayed at the beginning of the game. If no records are saved yet,
the option 1 will be selected and the quiz questions will be displayed. The user is expected to answer the questions and
Correct/Wrong will be displayed after entering a response. When the questions are finished, the user score will be displayed
and a question will pop up to ask the user if they want to save their score. If yes, they are expected to type their name.
Their entries will be saved to an another file (will be created if it is the first time of the game playing) with their score
and name. 

The option 2 will use the file created to reach the records and display the top 5 (if available) highest scores in the file.
  
