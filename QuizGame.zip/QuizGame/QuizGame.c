
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int displayMenu();
int startQuiz(char ***);
void loadQuestions(char ***);
int askQuestion(char **, int);
char getUserInput();
void saveHighScores(char **);
void viewHighScores(char ***);
int loadHighScores(char ***);


int main()
{
    int u_choice, score;   // user choice
    char ***questions, name[20], save;
    char ***highScores, score_str[2];
    int i, j, k, *temp_score;
    int position=0;  // represents the position/number of the highScores array elements per each user recorded
    int pos, min;    // pos represents the position of the min element in the array to update the high scores array

    printf("Welcome to the C Programming Quiz Game!");

    temp_score = (int*)malloc(5 * sizeof(int));   // creating an array to save the scores to compare them when needed

    highScores = (char***)malloc(5 * sizeof(char**));
    for (i=0 ; i<5 ; i++)
        highScores[i] = (char**)malloc(2 * sizeof(char*));   // 6 represents the lines for each question (question itself, 4 options and the answer -> 6 in total)

    for (i=0 ; i<5 ; i++){
        for (j=0 ; j<2 ; j++)
            highScores[i][j] = (char*)malloc(20 * sizeof(char)); }   // 500 represents the characters for each line read, can be increased/decreased based on the question length

    // allocating enough space in the memory for the highScores array
    for (i=0; i<5; i++){
        for (j=0; j<2; j++){
            for(k=0 ; k<20 ; k++)
                highScores[i][j] = (char*)malloc(20 * sizeof(char));  }}

    do
    {
        u_choice = displayMenu();

        switch(u_choice)
        {
            case 1:
                 // questions array to keep track of all the questions/options and correct answers in the file
                questions = (char***)malloc(10 * sizeof(char**));   // 10 represents the number of questions

                for (i=0 ; i<10 ; i++)
                    questions[i] = (char**)malloc(6 * sizeof(char*));   // 6 represents the lines for each question (question itself, 4 options and the answer -> 6 in total)

                // dynamically allocating memory for the questions pointer array
                // 2D array allocation here
                for (i=0 ; i<10 ; i++){
                    for (j=0 ; j<7 ; j++)
                        questions[i][j] = (char*)malloc(500 * sizeof(char)); }   // 500 represents the characters for each line read, can be increased/decreased based on the question length

                // 3D array memory allocation here
                for (i=0; i<10; i++){
                    for (j=0; j<7; j++){
                        for(k=0 ; k<500 ; k++)
                            questions[i][j] = (char*)malloc(500 * sizeof(char));  }}

                score = startQuiz(questions);   // sending the questions array to the function to populate it
                printf("\nDo you want to save your score? (Y/N): ");
                scanf(" %c",&save);

                // saving the name and the score to the highScores array (if it's not already full) if the user wants to save them
                if((save=='Y' || save=='y') && position<5){
                    printf("Enter your name: ");
                    scanf("%s", name);
                    strcpy(highScores[position][0],name);
                    sprintf(score_str,"%d",score);
                    strcpy(highScores[position][1],score_str);
                    temp_score[position] = score; // coping the scores to a temporary array

                    saveHighScores(highScores[position]);   }

                else if((save=='Y' || save=='y') && position>=5){
                    printf("Enter your name: ");
                    scanf("%s", name);

                    // calculating the min score recorded overall
                    min = temp_score[0];
                    for(i=1 ; i<3 ; i++){
                        if(temp_score[i]<min){
                            min = temp_score[i];
                            pos = i;  }   }

                    // checking if the new score is worth saving (not less than the ones already saved)
                    if(score>=min){
                        temp_score[pos] = score;
                        strcpy(highScores[pos][0],name);
                        sprintf(score_str,"%d",score);
                        strcpy(highScores[pos][1],score_str);   }

                    saveHighScores(highScores[pos]);  } // save the content to the file
                break;

            case 2:
                viewHighScores(highScores);
                break;

            case 3:
                printf("Goodbye!\n");
                break;
            default:
                printf("Invalid option is entered! Please try again :)");
                break;
        }

        position++;

    } while(u_choice!=3);

    return 0;
}


// function to display the user menu
int displayMenu()
{
    int choice;
    printf("\n\nMenu:\n1.Start Quiz\n2.View High Scores\n3.Quit\n\n");
    printf("Enter your choice: ");
    scanf("%d",&choice);
    return choice;
}

// function to keep track of the file reads and users' answers&scores
int startQuiz(char *** questions)
{
    int i, j, score=0;
    loadQuestions(questions);

    for(i=0 ; i<10 ; i++){
        printf("\nQuestion %d: \n", i+1);
        score = askQuestion(questions[i],score); } // sending the array in a way that it shows the user one question at a time

    printf("\nYou completed the quiz! Your score: %d/10\n", score);

    return score;
}

// function to load the content from the specified file to an array (questions)
void loadQuestions(char ***questions)
{
    int counter=0, i, j, k, y=0;
    char *fileName = "questions.txt";
    char temp[100], ans, answers[10];
    char line[500]; // variable to assign as the lines of the file to read
    char **array;

    FILE* file = fopen(fileName, "r");  // opening the specified file to read

    if(file==NULL){
        printf("File %s could not open to read!\n", fileName);
        exit(-1);   }

    // dynamic memory allocation for the array created to keep questions, options and answers per question
    array = (char**)malloc(100*sizeof(char*));    // reserving enough space for all the 10 questions (the value can be increased based on the number of questions/lines in the file)
    for(i=0 ; i<101 ; i++)
        array[i] = (char*)malloc((500)*sizeof(char));

    // assigning 0 values to i and j to use them in the loop
    i=0;
    j=0;

    printf("\nLoading quiz questions...\n");

    // reading the file line by line while it is not NULL (end of the file)
    while (fgets(line, sizeof(line), file)) {
        counter++;  // counting the lines
        strcpy(temp,line);  // coping the line content to a temp array
        strcpy(array[i],temp);  // saving each line to the array

        i++;    // incrementing array position

        // if it hits the position of multiples of 7, then it means the current question is over and the next question is coming (as 1 question occupies 6 lines)
        if(counter%7==0){
            ans = temp[16]; // 16 is the position of the answer based on the format in the file (Correct Answer: _)
            answers[j] = ans;   // saving the correct answers to an array to compare with it with user's choice later
            j++;    // incrementing the position of answers array

            for(k=0 ; k<6 ; k++)    // coping the array content to the questions array for each question after every read of any question
                strcpy(questions[y][k],array[k]);

            i=0;    // assigning 0 value as the new question will be read and saved to the 'array' array
            y++;    // keeping track of the number of questions in the questions array (for the position)
        }
    }

    answers[j] = line[16];  // saving the answer for the last question

    // saving the content of the last question to the questions array
    for(k=0 ; k<6 ; k++)
        strcpy(questions[y][k],array[k]);
}

// function to show one question at a time to the user and check their answer to calculate their score
int askQuestion(char **questions, int score)
{
    int i;
    char user_ans, correct_ans;

    // presenting questions one by one
    for(i=0;i<5;i++)
        printf("%s", questions[i]);

    user_ans = getUserInput();
    correct_ans = questions[i][16]; // the last line of the question is the correct answer and the letter is at the 16th position based on the format of the given file
    if(user_ans==correct_ans){
        printf("Correct!!\n");
        score++;    }
    else
        printf("Wrong!!\n");
    return score;
}

// function to get the user's answer for the questions
char getUserInput()
{
    char choice;

    printf("Your choice: ");
    scanf(" %c",&choice);

    return choice;
}

// function to save the array content (high scores and names) to a file
void saveHighScores(char **array)
{
    int i;

    FILE *fp = fopen("results.txt", "a+");  // creating (if not already exists) and opening the file to write

    if(fp==NULL){
        printf("File results.txt could not open to read/write!\n");
        exit(-1);   }

    // writing the array content to a file
    for(i=0 ; i<2 ; i++){
        fputs(array[i],fp);
        fputs(" ",fp);  }
    fputs("\n",fp);

    fclose(fp);
}

// function to display the top 5 scores with its information
void viewHighScores(char ***array)
{
    int i, size;
    size = loadHighScores(array);

    // checking if the file is successfully opened
    if(size==-1)
        return -1;

    printf("\nTop %d High Scores:\n", size);
    for(i=0 ; i<size ; i++){
        printf("%d. %s - %s/10\n", i+1, array[i][0], array[i][1]);  }
    printf("\nYou can do better! Keep going!\n");
}

// function to read the scores from a file and populates/updates the highScores array for the top 5 highest scores
int loadHighScores(char ***highScores)
{
    int i, j, counter=0, **scores;
    int line_count, pos, holder, size;
    char **array, **names, temp[100];
    char *fileName = "results.txt";
    char line[20], *token, holder_name[20], score_str[2];

    FILE* file = fopen(fileName, "r");  // opening the specified file to read

    if(file==NULL){
        printf("File %s could not open to read!\n", fileName);
        exit(-1);   }

    // memory allocation for the temp array to save data from the file
    array = (char**)malloc(20 * sizeof(char*));
    for (i=0 ; i<21 ; i++)
        array[i] = (char*)malloc(20 * sizeof(char));

    i=0;
    // reading the file line by line while it is not NULL (end of the file)
    while (fgets(line, sizeof(line), file)) {
        counter++;  // counting the lines
        strcpy(temp,line);  // coping the line content to a temp array
        strcpy(array[i],temp);  // saving each line to the array

        // incrementing array position
        i++;  }

    line_count = i; // saving the number of lines in the file to use it as size to return and split the data

    // allocating memory for names and scores arrays (temp arrays to split the data read from the txt file)
    names = (char**)malloc(line_count * sizeof(char*));
    for (i=0 ; i<line_count ; i++)
        names[i] = (char*)malloc(20 * sizeof(char));

    scores = (int**)malloc(line_count * sizeof(int*));
    for (i=0 ; i<line_count ; i++)
        scores[i] = (int*)malloc(2 * sizeof(int));

    // splitting the data read into names and scores
    for(i=0 ; i<line_count ; i++){
        token = strtok(array[i]," ");
        strcpy(names[i],token);
        token = strtok(NULL," ");
        // converting str to an int to to comparison later for the highest score calculation
        scores[i] = atoi(token);   }

    // arranging the data read from the file to be in the descending order
    for(i=0 ; i<line_count ; i++){
        for(j=i+1 ; j<line_count ; j++){
            if(scores[i]<scores[j]){
                holder = scores[i];
                strcpy(holder_name,names[i]);
                scores[i] = scores[j];
                strcpy(names[i],names[j]);
                scores[j] = holder;
                strcpy(names[j],holder_name);   }   }   }

    if(line_count>5)
        size=5;
    else
        size = line_count;

    // updating the highScores array with the sorted values
    for(i=0 ; i<size ; i++){
        strcpy(highScores[i][0],names[i]);
        sprintf(score_str,"%d",scores[i]);
        strcpy(highScores[i][1],score_str); }

    return size;
}

