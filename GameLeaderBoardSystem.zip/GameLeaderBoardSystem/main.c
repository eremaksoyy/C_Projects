
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 20

struct score_table {
	char team1[SIZE] ;
	char team2[SIZE] ;
	int  score1 ;
	int  score2 ; 	};   
	
struct league_table {
	char team_name[SIZE] ;
	int  win ;
	int  draw ;
	int  loss ;
	int  points ;
	int  average ;
	int  goals ;	};

FILE *inFile ;
int load_scoretable(char [], struct score_table *) ;
void create_leaguetable(struct score_table *, struct league_table *, int) ;
void order_leaguetable(struct league_table *, int ) ;
void display_leaguetable(struct league_table *, int) ;
void search_team(struct league_table *, int) ;

int main()
{
	int i, size ;
	char choice ;
	char filename[SIZE] = {"Scoretable.txt"} ;
	char *team1_name[SIZE] = {"Galatasaray", "Fenerbahce", "Alanyaspor", "Rizespor", "Goztepe"} ;
	char *team2_name[SIZE] = {"Besiktas", "Denizlispor", "Trabzonspor", "Konyaspor", "Antalyaspor"} ;
	int  team1_score[SIZE] = {2, 0, 1, 0, 1} ;
	int  team2_score[SIZE] = {3, 0, 5, 1, 1} ;
	
	inFile = fopen(filename, "w") ;
	if (inFile == NULL)	{
		printf("The file could not open for reading/writing successfully! ") ;
		exit(1) ;	}
	for (i=0 ; team1_name[i] != NULL ; i++)	{
		fprintf(inFile, "%-20s 	%-20s 	 %-20d		%-20d\n", team1_name[i], team2_name[i], team1_score[i], team2_score[i]) ;	 }
	fclose(inFile) ;
	
	struct score_table *team_infos ;
	team_infos = (struct score_table *) malloc(sizeof(struct score_table) * SIZE) ;		//Here it allocates the structure but in the load_function if the size is not enough, it will be allocated again.
	size = load_scoretable(filename, team_infos) ;
	
	struct league_table *league_infos ;
	league_infos = (struct league_table *)malloc(sizeof(struct league_table) * (2*size)) ;
	create_leaguetable(team_infos, league_infos, size) ;
	order_leaguetable(league_infos, size) ;	
	display_leaguetable(league_infos, size) ;
	
	do {														//This loop will ask the user if they want to search a team or exit the page until they want to exit .
		printf("Press E/e for exit or S/s for search:  ") ;
		scanf(" %c", &choice) ;
		
			if (choice == 's' || choice == 'S') 	
				search_team(league_infos, size) ;	
			else if (choice == 'e' || choice == 'E' )	{
				printf("Wishing you a successful week!  \n") ; 
				break ; }  
			else
				printf("Invalid value entered! Please enter E/e or S/s !\n ") ;
		} while (choice != 'E' || choice != 'e') ;	
	return 0 ;
}

int load_scoretable(char filename[], struct score_table *team_infos)		//This function will load the date from the file and will give the number of size of structure .
{
	int i, size ;
	inFile = fopen(filename, "r") ;   
	
	if (inFile == NULL)	{
		printf("The file could not read successfully! \n") ;
		exit(1) ;	}	
	
	for (i=0 ; team_infos[i].team1 != NULL ; i++)	{
		fscanf(inFile, "%s", team_infos[i].team1) ;
		fscanf(inFile, "%s", team_infos[i].team2) ;
		fscanf(inFile, "%d", &team_infos[i].score1) ; 
		fscanf(inFile, "%d", &team_infos[i].score2) ;
		if(feof(inFile)) 
			break;	}
	size = i ;
	if (size > SIZE) 	{
		team_infos = (struct score_table *) realloc(team_infos, sizeof(struct score_table) * SIZE) ;		//This part will dynamically allocate the size of structure if there is more element to put.
		size ++ ;	}	
	if (team_infos == NULL )	{
		printf("The structure could not allocate again and the file couldn't be loaded successfully! \n") ;
		exit(-1) ;	}

	printf("Score records file has been successfully loaded! \n") ;
	printf("Following records have been loaded:  \n\n") ;	
	printf("  Team 1	     Team 2 	  Team1 Score 	Team2 Score\n") ;
	printf("-----------  	    -----------   -----------  -------------\n") ;
	for(i=0 ; i<size ; i++)
		printf("%-20s%-20s%-10d %-20d \n", team_infos[i].team1, team_infos[i].team2, team_infos[i].score1, team_infos[i].score2) ;	
	printf("\n\n") ;
	
	fclose(inFile) ;
	return size ;
}

void create_leaguetable(struct score_table *team_infos, struct league_table *league_infos, int size)			//This function will take a league structure and create a league table which includes number of wins, losses, average, etc. of all teams in the scoretable . 
{	
	int i, j, k ;
	int newsize = 2 * size ;		//The number of rows should be doubled as all teams will be in different lines .

	for (i=0 ; i<newsize ; i++)	{		//All number should be assigned to 0 at the beginning as their win, loss, points, etc.(except average because everage will be taken from the score table an dit will not change ) will increase/decrease due to their performance . 
		league_infos[i].win = 0 ;
		league_infos[i].draw = 0 ;	
		league_infos[i].loss = 0 ;
		league_infos[i].points = 0 ;	
		league_infos[i].goals = 0 ;		}
		
		i = 0 ;
		j = i ;
		k = j + 1 ;		

	for (; i<size ; i++)	{			//This loop  will copy the all content of score table to the league table .
		strcpy(league_infos[j].team_name, team_infos[i].team1) ;
		strcpy(league_infos[k].team_name, team_infos[i].team2) ;
		
		if (team_infos[i].score1 > team_infos[i].score2)	{
			league_infos[j].win += 1 ;
			league_infos[k].loss += 1 ;
			league_infos[j].points += 3 ;		}
		else if (team_infos[i].score1 == team_infos[i].score2) 	{
			league_infos[j].draw += 1 ;
			league_infos[k].draw += 1 ;
			league_infos[j].points += 1 ;
			league_infos[k].points += 1 ;	}
		else	{
			league_infos[k].win += 1 ;
			league_infos[j].loss += 1 ;
			league_infos[k].points += 3 ;	}
			
			league_infos[j].goals = team_infos[i].score1 ;
			league_infos[k].goals = team_infos[i].score2 ;			
			
			league_infos[j].average = team_infos[i].score1 - team_infos[i].score2 ;
			league_infos[k].average = team_infos[i].score2 - team_infos[i].score1 ;
			j += 2 ;
			k += 2 ;	}	
}

void order_leaguetable(struct league_table *league_infos, int size)			//This functin will order the new team list by considering the win, average and goals number(when it is necessary) .
{
	int  i, j, win, draw, loss, points, average, goals ;
	char array[SIZE] ;
	
	for (i=0 ; i<2*size ; i++)	{					//This loop will switch the values to sort the data again due to specifications (win, average and goals) .
		for (j=i+1 ; j<2*size ; j++)	{
		if (league_infos[i].win == league_infos[j].win)	{
			if (league_infos[i].average < league_infos[j].average)	{
				strcpy(array, league_infos[i].team_name) ;
				strcpy(league_infos[i].team_name, league_infos[j].team_name) ;
				strcpy(league_infos[j].team_name, array) ;
				
				win = league_infos[i].win ;
				league_infos[i].win = league_infos[j].win ;
				league_infos[j].win = win ;
				
				draw = league_infos[i].draw ;
				league_infos[i].draw = league_infos[j].draw ;
				league_infos[j].draw = draw ;
				
				loss = league_infos[i].loss ;
				league_infos[i].loss = league_infos[j].loss ;
				league_infos[j].loss = loss ;
				
				points = league_infos[i].points ;
				league_infos[i].points = league_infos[j].points ;
				league_infos[j].points = points ;
				
				average = league_infos[i].average ;
				league_infos[i].average = league_infos[j].average ;
				league_infos[j].average = average ;
				
				goals = league_infos[i].goals ;
				league_infos[i].goals = league_infos[j].goals ;
				league_infos[j].goals = goals ;	}
			else if (league_infos[i].average == league_infos[j].average)	{
				if (league_infos[i].goals < league_infos[j].goals)	{
					strcpy(array, league_infos[i].team_name) ;
					strcpy(league_infos[i].team_name, league_infos[j].team_name) ;
					strcpy(league_infos[j].team_name, array) ;
					
					win = league_infos[i].win ;
					league_infos[i].win = league_infos[j].win ;
					league_infos[j].win = win ;
					
					draw = league_infos[i].draw ;
					league_infos[i].draw = league_infos[j].draw ;
					league_infos[j].draw = draw ;
					
					loss = league_infos[i].loss ;
					league_infos[i].loss = league_infos[j].loss ;
					league_infos[j].loss = loss ;
					
					points = league_infos[i].points ;
					league_infos[i].points = league_infos[j].points ;
					league_infos[j].points = points ;
					
					average = league_infos[i].average ;
					league_infos[i].average = league_infos[j].average ;
					league_infos[j].average = average ;
					
					goals = league_infos[i].goals ;
					league_infos[i].goals = league_infos[j].goals ;
					league_infos[j].goals = goals ;	}	}	}
		else if (league_infos[i].win < league_infos[j].win)	{
			strcpy(array, league_infos[i].team_name) ;
			strcpy(league_infos[i].team_name, league_infos[j].team_name) ;
			strcpy(league_infos[j].team_name, array) ;
			
			win = league_infos[i].win ;
			league_infos[i].win = league_infos[j].win ;
			league_infos[j].win = win ;
			
			draw = league_infos[i].draw ;
			league_infos[i].draw = league_infos[j].draw ;
			league_infos[j].draw = draw ;
			
			loss = league_infos[i].loss ;
			league_infos[i].loss = league_infos[j].loss ;
			league_infos[j].loss = loss ;
			
			points = league_infos[i].points ;
			league_infos[i].points = league_infos[j].points ;
			league_infos[j].points = points ;
			
			average = league_infos[i].average ;
			league_infos[i].average = league_infos[j].average ;
			league_infos[j].average = average ;
			
			goals = league_infos[i].goals ;
			league_infos[i].goals = league_infos[j].goals ;
			league_infos[j].goals = goals ;	}	}	}	
}

void display_leaguetable(struct league_table *league_infos, int size)			//This function will display the new sorted content of league table .
{
	int i ;
	
	printf("Formed League Table is as follows:  \n\n") ;
	printf("  Team 	    	    Win	       Draw	  Loss 	    Points    Average	  Goals\n") ;
	printf("-----------       ------      ------    -------    --------   --------    -------\n") ;

	for (i=0 ;	i<2*size ; i++)
		printf("%-20s %-10d %-10d %-10d %-10d %-10d %-10d\n", league_infos[i].team_name, league_infos[i].win, league_infos[i].draw, league_infos[i].loss, league_infos[i].points, league_infos[i].average, league_infos[i].goals) ;
	printf("\n\n") ;
}

void search_team(struct league_table *league_infos, int size)		//This function will search if the entered team is in the league table or not . 
{
	int i, counter=0 ;
	char team_choice[SIZE] ;
	
	printf("Enter the name of the team you want to search:  ") ;
	scanf("%s", team_choice) ;
	for (i=0 ; i<2*size ; i++)	{
		if (strcmp(team_choice, league_infos[i].team_name) == 0)	{	
			printf("%s 's rank is %d .\n\n", league_infos[i].team_name, (i+1)) ;
			counter ++ ;	}	}
	if (counter==0)	
		printf("That team is unknown! Please try again! \n\n") ;
}

