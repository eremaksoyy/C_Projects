#include<stdio.h>
#include<stdlib.h>
#include "queue.h"

int main()
{
	int current_time=0, ending_time ;
	Robot *R, *first, *last ;
	R = (Robot *)malloc(sizeof(Robot)) ;
	Queue *Q, *CoffeeQueue ;
	Q = makeEmptyQueue() ;
	CoffeeQueue = makeEmptyQueue() ;
	int id_num, start, service, deq_element ;
	FILE *inFile ;
	inFile = fopen("customer_info.txt", "r") ;
	if (inFile == NULL)	{
		printf("Reading the required file is not successful!\n") ;
		exit(1) ;	}
	while(!feof(inFile))	{
		fscanf(inFile, "%d %d %d\n", &id_num, &start, &service) ;
		enqueue(Q,id_num,start,service) ;	}
	if(Q->front != NULL)
		printf("The file has been loaded successfully!\n\n") ;
	printf("--------- Simple Coffee Shop System ---------") ;

	Robot *Holder;
	Holder=(Robot *)malloc(sizeof(Robot)) ;
	Holder->next=NULL ;
	R = Holder ;
	first = last = NULL ;
	Node *tmp;
	tmp = Q->front->next ;
	while(tmp != NULL)	{
		if(current_time == 0)	{
			while(current_time != tmp->starting_time)	{
				current_time++ ;	} 
			Robot *Holder ;
			Holder=(Robot *)malloc(sizeof(Robot)) ;
			Holder->startTime = current_time ;
			Holder->duration = tmp->service_time ;	
			Holder->next = NULL;
			R->next = Holder ;
			first = last = Holder ;
			ending_time = last->startTime + last->duration ;
			tmp = tmp->next ;
			deq_element = dequeue(Q, CoffeeQueue) ;	}
		else { 
			while(current_time != tmp->starting_time)	{
				current_time ++ ;	}
			Robot *temp ;
			temp = (Robot *)malloc(sizeof(Robot)) ;
			temp->startTime = ending_time ;
			temp->duration = tmp->service_time ;
			temp->next = NULL ;
			ending_time = temp->startTime + temp->duration ;
			last->next = temp ;
			last = temp ;
			tmp = tmp->next ;
			deq_element = dequeue(Q, CoffeeQueue) ;	}	}

		display(CoffeeQueue,R) ;
	return 0 ;
}
