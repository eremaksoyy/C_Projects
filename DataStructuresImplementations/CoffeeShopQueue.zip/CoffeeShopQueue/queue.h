
typedef struct node {
	int id;
	int starting_time;
	int service_time;
	struct node *next;
} Node;

typedef struct QueueRecord {
	Node *front;
	Node *rear;
	int size;
} Queue;

typedef struct robot {
	int startTime;
	int duration;
	struct robot *next ;
} Robot;

void enqueue(Queue *, int, int, int);
Queue *makeEmptyQueue();
int dequeue(Queue *, Queue *);
void display(Queue *, Robot *) ;


void enqueue(Queue *Q, int id_num, int start, int service)
{
	Node *temp ;
	temp = (Node *)malloc(sizeof(Node)) ;
	temp->id = id_num ;
	temp->starting_time = start ;
	temp->service_time = service ;
	temp->next = NULL ;
	Q->rear->next = temp ;
	Q->rear = temp ;
	Q->size ++ ;
}

int dequeue(Queue *Q, Queue *CoffeeQueue)
{
	int holder ;
	Node *deleteNode, *tmp ;
	deleteNode = Q->front->next ;
	holder = deleteNode->id ;
	Q->front->next = deleteNode->next ;
	Q->size -- ;

    tmp = (Node *)malloc(sizeof(Node)) ;
    tmp->id = deleteNode->id ;
    tmp->starting_time = deleteNode->starting_time ;
    tmp->service_time = deleteNode->service_time ;
    tmp->next = NULL ;
	CoffeeQueue->rear->next = tmp ;
	CoffeeQueue->rear = tmp ;
	CoffeeQueue->size ++ ;
	free(deleteNode) ;
	return holder ;
}

Queue *makeEmptyQueue()
{
	Queue *Q;
	Q = (Queue *)malloc(sizeof(Queue)) ;
	if(Q == NULL)	{
		printf("Queue could't allocated!\n") ;
		exit(1) ; }
	else {
		Q->front = (Node *)malloc(sizeof(Node)) ;
		if(Q->front == NULL)	{
			printf("Allocation is not successful!\n") ;
			exit(1) ;	}
		Q->front->next = NULL ;
		Q->rear = Q->front ;
		Q->size = 0 ;	}
	return Q ;
}

void display(Queue *Q, Robot *R)
{
	int i ;
	float avg, sum=0.0 ;
	int end_time, waiting_time ;
	Robot *robotTemp ;
	robotTemp = R->next ;
	Node *tmp ;
	tmp = Q->front->next ;
	for(i=0 ; i<Q->size ; i++)	{
		waiting_time  = robotTemp->startTime - tmp->starting_time ;
		end_time = robotTemp->duration + robotTemp->startTime ;
		printf("\nOrder ID: %d", tmp->id) ;
		printf("\nStart Time: %d", robotTemp->startTime) ;
		printf("\nEnd Time: %d", end_time) ;
		printf("\nWaiting time: %d", waiting_time) ;
		tmp=tmp->next ;
		robotTemp = robotTemp->next ;
		sum += waiting_time ;	}
	avg = sum/Q->size ;
	printf("\nThe average waiting time of the system is %.1f\n", avg) ;
}


