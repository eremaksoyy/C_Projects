#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<time.h>
#include "list_header.h"

void parseInput(char **, int *, int *, int *, int *) ;
void initialiseSimulator(Queue *Q, int *, int, int) ;
int randomiser(int) ;
void newPatient (Queue *, Queue *, List *, int *, int, int) ;

int main(int argc, char **argv)
{
	int max_arrival, max_service, ventilator_num, patient_num, time=0 ;
	if(argc==1){
		printf("There is no element!\n") ;
		exit(1) ;	}

	Queue *PatientQueue, *NewQueue ;
	NewQueue = (Queue *)malloc(sizeof(Queue)) ;
	if (NewQueue == NULL)	{
		printf("Allocation of queue is not successful!\n") ;
		exit(0) ;	}
	NewQueue->front = (Node *)malloc(sizeof(Node)) ;
	makeEmptyQueue(NewQueue) ;
	PatientQueue = (Queue *)malloc(sizeof(Queue)) ;
	if (PatientQueue == NULL)	{
		printf("Allocation of queue is not successful!\n") ;
		exit(0) ;	}
	PatientQueue->front = (Node *)malloc(sizeof(Node)) ;
	printf("********************** Report **********************\n") ;
	List *PatientList ;
	parseInput(argv, &patient_num, &ventilator_num, &max_arrival, &max_service) ;
	int ventilators[ventilator_num] ;
	initialiseSimulator(PatientQueue, ventilators, patient_num, ventilator_num) ;
	PatientList = createPatientList(max_arrival,max_service,patient_num) ;
	newPatient (PatientQueue, NewQueue, PatientList, ventilators, ventilator_num, patient_num) ;

	return 0 ;
}

void parseInput(char *argv[], int *patient_num, int *ventilator_num, int *max_arrival, int *max_service)	//This function parse the input and set the values.
{
	if(argv[0]!=NULL){
		*patient_num = atoi(argv[1]) ;
		*ventilator_num = atoi(argv[2]) ;
		*max_arrival = atoi(argv[3]) ;
		*max_service = atoi(argv[4]);	}
	else	{
		printf("Please enter a value! This is an empty array!\n") ;
		exit(1) ;	}
}

void initialiseSimulator(Queue *Q, int *ventilators, int patient_num, int ventilator_num)	//This function creates an empty queue and an integer array to keep the track of the ventilators.
{
	int i;
	makeEmptyQueue(Q) ;
	for(i=0 ; i<ventilator_num ; i++)	{
		ventilators[i] = 1 ;	}
}

int randomiser(int max_value)	//It takes an integer randomly according to the given max value.
{
	int num ;
	num = rand()%(max_value) ;
	return num ;
}

void newPatient(Queue *Q, Queue *Q2, List *L, int *ventilators, int ventilator_num, int patient_num)	//This function takes a patient by looking at the arrival time and add them to the queue(as a priority queue).
{
	int usedVentilator, i ;
	int time=0, *total_waiting =0, keepTrackVentilators[ventilator_num] ;
	Node *holder, *newPatient, *node ;
	for(i=0 ; i<ventilator_num ; i++)	{
		keepTrackVentilators[i] = 0 ;	}
	while(!isEmptyList(L) || checkAvailable(ventilators, ventilator_num)==0){
		if(!isEmptyList(L) && time>=L->head->next->arrival_time)	{
			if(checkAvailable(ventilators, ventilator_num)!=0)	{
				if(Q->size != 0)	{
					node =	dequeue(Q) ;	}
				else {
					if(checkAvailable(ventilators, ventilator_num)>1)	{
						holder = removeFromList(Q2, L) ;
						servePatient(&total_waiting, time, ventilator_num, ventilators, holder) ;	}
					else	{
						newPatient = removeFromList(Q2, L) ;

						servePatient(&total_waiting, time, ventilator_num, ventilators, newPatient) ;	}	}	}
			else	{
				Node *temp ;
				temp=(Node *)malloc(sizeof(Node)) ;
				enqueue(Q, temp) ;	}	}
	 	if(checkAvailable(ventilators, ventilator_num)!=ventilator_num)	{
			if(holder->service_start_time+holder->service_time==time)	{
				usedVentilator = holder->ventilator_ID-1 ;
				ventilators[usedVentilator] = 1 ;
				keepTrackVentilators[usedVentilator] ++ ;	}
			else if(newPatient->service_start_time+newPatient->service_time==time)	{
				usedVentilator = newPatient->ventilator_ID-1 ;
				ventilators[usedVentilator] = 1 ;
				keepTrackVentilators[usedVentilator] ++ ;	}	}
		time ++ ;	}
		time -- ;

	reportStatistics(Q2, patient_num, &total_waiting, keepTrackVentilators, ventilator_num) ;
}

int decidePriority(Node *N)	//This function converts the char type of the priority to an integer type.
{
	int num ;
	char priority ;
	priority = N->type ;

	switch(priority){
		case 'S':
			num = 3 ;
			break ;
		case 'D':
			num = 2 ;
			break ;
		case 'M':
			num = 1 ;
			break ;	}
	return num ;
}

int checkAvailable(int *ventilators, int ventilator_num)	//This function check if there is an available ventilator or not.
{
	int i, counter=0;
	for(i=0 ; i<ventilator_num ; i++)	{
		if(ventilators[i] == 1)
			counter ++ ;	}
	return counter ;
}

void servePatient(int *total_waiting, int time, int ventilator_num, int *ventilators, Node *N)	//This function takes the patient from the queue and serve by updating the necessary values.
{
	int num, waiting ;
	num = randomiser(ventilator_num) ;
	while(ventilators[num] = 0)	{
		num = randomiser(ventilator_num) ;	}
	N->ventilator_ID = num+1 ;
	ventilators[num] = 0 ;
	N->service_start_time = time ;
	waiting = N->service_start_time-N->arrival_time ;
	*total_waiting += waiting ;
}

void reportStatistics(Queue *Q, int patient_num, int *total_waiting, int *ventilators_track, int ventilator_num)	//This function reports the required statistical data.
{
	float avg ;
	int patientType_track[]={0, 0, 0}, num, i, max, gender_track[]={0, 0}, age_track[]={0, 0, 0} ;
	Node *tmp, *node, *newone ;
	tmp = (Node *)malloc(sizeof(Node)) ;
	if(tmp == NULL)	{
		printf("Allocation is not successful!\n") ;
		exit(1) ;	}
	tmp = Q->front->next ;
	while(tmp != NULL)	{
		num = decidePriority(tmp) ;
		patientType_track[num-1] ++ ;
		if(tmp->gender == 'M')
			gender_track[0] ++ ;
		else
			gender_track[1] ++ ;
		if(tmp->age_group == 'E')
			age_track[0] ++ ;
		else if (tmp->age_group == 'A')
			age_track[1] ++ ;
		else
			age_track[2] ++ ;
		tmp = tmp->next ;	}

	node = (Node *)malloc(sizeof(Node)) ;
	if(node == NULL)	{
		printf("Allocation is not successful!\n") ;
		exit(1) ;	}
	node = Q->front->next ;
	max = node->service_start_time-node->arrival_time ;
	while(node->next != NULL)	{
		node = node->next ;
		if(max < (node->service_start_time-node->arrival_time))
			max = node->service_start_time-node->arrival_time ;	}

/*	newone = (Node *)malloc(sizeof(Node)) ;
	if(newone == NULL)	{
		printf("Allocation is not successful!\n") ;
		exit(1) ;	}
	newone=Q->front->next ;
	printf("\n\n\n") ;
	while(newone != NULL)	{
		printf("%5c%4d%4d%4d%4d%5c%5c \n",newone->type, newone->arrival_time, newone->service_time, newone->service_start_time, newone->ventilator_ID, newone->gender, newone->age_group) ;
		newone=newone->next ;	}	*/ 	//This part prints the last version of the data for patients as a table.

	printf("\nThe number of ventilators: %d\n", ventilator_num) ;
	printf("The number of patients: %d\n", patient_num) ;
	printf("Number of patients for each patient type:\n") ;
	printf("\t Severe(S): %d\n", patientType_track[2]) ;
	printf("\t Moderate(D): %d\n", patientType_track[1]) ;
	printf("\t Mild(M): %d\n", patientType_track[0]) ;

	printf("Number of patients for each ventilator: \n") ;
	for(i=0 ; i<ventilator_num ; i++)	{
		printf("\tVentilator %d: %d\n", i+1, ventilators_track[i]) ;	}
	avg = (float)*total_waiting/patient_num ;
	printf("\nAverage time spend in the queue  %.1f\n", avg) ;
	printf("Maximum waiting time : %d\n", max) ;
	printf("Most gender usage: ") ;
	if(gender_track[0]>gender_track[1])
		printf("Male\n") ;
	else
		printf("Female\n") ;

	printf("Most age usage: ") ;
	if(age_track[0]>age_track[1] && age_track[0]>age_track[2])
		printf("Elderly\n") ;
	else if (age_track[1]>age_track[0] && age_track[1]>age_track[2])
		printf("Adult\n") ;
	else if (age_track[2]>age_track[0] && age_track[2]>age_track[1])
		printf("Young\n");
	else
		printf("Non! There are equal numbers for two age groups!\n") ;
}

