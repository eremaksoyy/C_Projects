
typedef struct Node {
	char type ;
	int arrival_time ;
	int service_time ;
	int service_start_time ;
	int ventilator_ID ;
	char gender ;
	char age_group ;
	struct Node *next ;
} Node; 

typedef struct QueueRecord {
	Node *front ;
	Node *rear ;
	int size ;
} Queue;

void makeEmptyQueue(Queue *Q)
{
	Q->front->next = NULL ;
	Q->rear = Q->front ;
	Q->size = 0 ;	
}

int isEmptyQueue(Queue *Q)
{
	if(Q->size == 0)
		return 1;
	else
		return 0 ;
}

void *enqueue(Queue *Q, Node *N)	//This function takes patient from the list and add it to the queue by considering the priorities.
{
	int priority_newPatient, priority_temp ;
	if(isEmptyQueue(Q))	{
		Q->front->next = N ;
		Q->rear = N ;	}
	else	{
		Node *temp;
		temp = (Node *)malloc(sizeof(Node)) ;
		if(temp == NULL)	{
			printf("Allocation is failed!\n") ;
			exit(1) ;	}
		temp = Q->front->next ;
		priority_newPatient = decidePriority(N) ;
		priority_temp = decidePriority(temp) ;
		while(temp->next!=NULL && priority_newPatient<=priority_temp)	{
			temp = temp->next ;	}
		N->next = temp->next ;
		temp->next = N ;
		while(temp->next != NULL)	{
			temp = temp->next ;	}
		Q->rear = temp ;	}
		Q->size ++ ; 
}

Node *dequeue(Queue *Q)	//This function takes the patient out of the queue if his/her time comes to be served by a ventilator.
{
	Node *temp ;
	temp = (Node *)malloc(sizeof(Node)) ;
	if(!isEmptyQueue(Q))	{
		Node *deleteNode ;
		deleteNode = (Node *)malloc(sizeof(Node)) ;	
		if(deleteNode == NULL)	{
			printf("Allocation is not successful!\n") ;
			exit(1) ;	}
		deleteNode = Q->front->next ;
		temp->age_group = deleteNode->age_group ;
		temp->arrival_time = deleteNode->arrival_time ;
		temp->gender = deleteNode->gender ;
		temp->type = deleteNode->type ;
		temp->service_start_time = deleteNode->service_start_time ;
		temp->service_time = deleteNode->service_time ;
		temp->ventilator_ID = deleteNode->ventilator_ID ; 
		temp->next = NULL ;
		Q->front->next = deleteNode->next ;
		free(deleteNode) ;
		Q->size -- ;
		if(Q->size == 0)	
			Q->rear = Q->front ;	}
	return temp ;
}

