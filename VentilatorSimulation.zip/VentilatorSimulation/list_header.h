#include "queue_header.h"

typedef struct ListRecord {
	Node *head ;
	Node *tail ;
	int size ;
} List;

void insertNode(List *L, Node *temp)	//This function adds the patient to the list according to their arrival time.
{
	if(L->size == 0)	{
		L->head->next = temp ;
		L->tail = temp ; }
	else	{
		Node *holder;
		holder = (Node *)malloc(sizeof(Node)) ;
		if(holder == NULL)	{
			printf("Allocation is not successful!\n") ;
			exit(1) ;	}
		holder = L->head ;
		while(holder->next!=NULL && holder->next->arrival_time<=temp->arrival_time)	{
			holder = holder->next ;	}
		if(holder->next == NULL)	{
			L->tail->next = temp ;
			L->tail = temp ;	}
		else	{
			temp->next = holder->next ;
			holder->next = temp ;	}	}
	L->size ++ ;
}

List *createPatientList (int max_arrival, int max_service, int patient_num)	//This function creates a list with the given/found randomly data of each patient.
{
	int i, num ;
	char patient_type[] = {'S', 'D', 'M'}, patient_gender[] = {'M', 'F'}, patient_ageGroup[] = {'E', 'A', 'Y'} ; 
	List *Patient ;	
	Node *tmp, *newone ;
	newone=(Node*)malloc(sizeof(Node)) ;
	Patient = (List *)malloc(sizeof(List)) ;
	Patient->head = (Node *)malloc(sizeof(Node)) ;
	if(Patient->head == NULL)	{
		printf("Allocation is not successful!\n") ;
		exit(1) ;	}
	Patient->head->next = NULL ;
	Patient->tail = Patient->head ;
	Patient->size = 0 ;
	srand(time(NULL)) ;
	for(i=0 ; i<patient_num ; i++)	{
		tmp = (Node *)malloc(sizeof(Node)) ;
		if(tmp == NULL)	{
			printf("Not successful!\n") ;
			exit(1) ;	}
		num = randomiser(3) ;
		switch(num){
			case 0 :
				tmp->type = patient_type[0] ;
				break;
			case 1:
				tmp->type = patient_type[1] ;
				break ;
			case 2:
				tmp->type = patient_type[2] ;
				break ;	}
		tmp->arrival_time = randomiser(max_arrival) ;
		tmp->service_time = randomiser(max_service)+1 ;
		tmp->service_start_time = 0 ;
		tmp->ventilator_ID = 0 ;
		num = randomiser(2) ;
		switch(num){
			case 0:
				tmp->gender = patient_gender[0] ;
				break ;
			case 1:
				tmp->gender = patient_gender[1] ;
				break ;	}
		num = randomiser(3) ;
		switch(num){
			case 0:
				tmp->age_group = patient_ageGroup[0];
				break ;
			case 1:
				tmp->age_group = patient_ageGroup[1] ;
				break ;
			case 2:
				tmp->age_group = patient_ageGroup[2] ;
				break ;	}
		tmp->next = NULL ;
		insertNode(Patient, tmp) ;	}

	newone=Patient->head->next ;
	while(newone != NULL)	{
		printf("%5c%4d%4d%4d%4d%5c%5c \n",newone->type, newone->arrival_time, newone->service_time, newone->service_start_time, newone->ventilator_ID, newone->gender, newone->age_group) ;
		newone=newone->next ;	}   //This function prints the values at the beggining as a table.
			
	return Patient;
}

int isEmptyList(List *L)
{
	if(L->size == 0)
		return 1 ;
	else
		return 0 ;
}

Node *removeFromList(Queue *Q, List *L)	//This function remove the patient from the list when their arrival time comes.
{
	Node *holder;
	holder=(Node*)malloc(sizeof(Node)) ;
	if(!isEmptyList(L))	{
		Node *remove;
		remove = (Node *)malloc(sizeof(Node)) ;
		if(remove == NULL)	{
			printf("Allocation to remove a node is not successful!\n") ;
			exit(1) ;	}
		remove = L->head->next ;
		holder->age_group = remove->age_group ;
		holder->arrival_time = remove->arrival_time ;
		holder->gender = remove->gender ;
		holder->type = remove->type ;
		holder->service_start_time = remove->service_start_time ;
		holder->service_time = remove->service_time ;
		holder->ventilator_ID = remove->ventilator_ID ; 
		holder->next = NULL ;
		Q->rear->next = holder ;
		Q->rear = holder ;
		Q->size ++ ;
		L->head->next = remove->next ;
		free(remove) ;
		L->size -- ;
		if(L->size == 0)
			L->tail = L->head ;	}
	else {
		printf("The list is already empty! You cannot remove any patient!\n") ;
		exit(1) ;	}
	return holder ;	
}

