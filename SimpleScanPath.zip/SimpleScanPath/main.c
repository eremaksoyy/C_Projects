
// Inputs for the program: aois.txt, fixations.txt

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#define SIZE 50

//STRUCT DEFINITIONS
typedef struct data1{
	char ElementName[10];
	int TopLeftX;
	int Width;
	int TopLeftY;
	int Height;	
} Data1;

typedef struct data2{
	int FixationID;
	int Xcoordinate;
	int Ycoordinate;
	int Duration;
} Data2;

typedef struct holder{
	int id;
	char letter[2*SIZE];
} Holder;

struct graphHead{
	int count;
	struct graphVertex *first;
};

struct graphVertex{
	struct graphVertex *next;
	struct holder Scanpath;
	int neighbor;
	int processed;
	struct graphArc *firstArc;
};

struct graphArc{
	int lcs;
	struct graphVertex *destination;
	struct graphArc *nextArc;
};

struct graphHead *createGraph();
int countPerson(char *);
int countSize(char *);
int max(int, int);
int lcs( char *, char *, int, int);
void insertVertex(struct graphHead *, struct holder);
struct graphHead *createVertices(char *, char *);
struct graphHead *createEdges(struct graphHead *, int *);
int insertArc(struct graphHead *, int, int,int);
void displayGraph(struct graphHead *);

// MAIN FUNCTION
int main(){
	int counter;
	char filename1[SIZE], filename2[SIZE];
	printf("Enter AOIs file name: ");
	gets(filename1);
	printf("Enter scanpaths file name: ");
	gets(filename2);

	struct graphHead *graph, *updatedGraph;
	graph = createVertices(filename1, filename2);	
	counter = countPerson(filename2);
	updatedGraph = createEdges(graph,counter);
	printGraph(updatedGraph);	
	
	return 0;
}


struct graphHead *createGraph(void){
	struct graphHead *head = (struct graphHead*)malloc(sizeof(struct graphHead));
	
	head->count = 0;
	head->first = NULL;
	
	return head;
}


int countPerson(char *filename){	//counts the number of person
	FILE *inFile;
	inFile = fopen(filename, "r");		//Opens the file to read the information from the file.
	if (inFile == NULL){
		printf("Opening file to read is not successful\n!");
		exit(1);	}
		
	int counter=0;		//Counts the number of the files.
	char tempArray[SIZE];
	int tempID;
	while(!feof(inFile)){
		fgets(tempArray, 2*SIZE, inFile);
		tempID = atoi(strtok(tempArray, " "));
		if(tempID==0)
			counter++;	}
	fclose(inFile);
	
	return counter;	
}


int countSize(char *filename){	//counts the size of the lines
	FILE *inFile;
	inFile = fopen(filename, "r");		//Opens the file to read the information from the file.
	if (inFile == NULL){
		printf("Opening file to read is not successful\n!");
		exit(1);	}
		
	int counter=0;		//Counts the number of the files.
	char tempArray[SIZE];
	while(!feof(inFile)){
		fgets(tempArray, 2*SIZE, inFile);
		counter++;	}
	fclose(inFile);
	
	return counter;	
}

int max(int a, int b){   
	return (a > b)? a : b;	}


int lcs( char *X, char *Y, int one, int second){
	int L[one+1][second+1];
	int i, j;
	for (i=0; i<=one; i++){
    	for (j=0; j<=second; j++){
    		if (i == 0 || j == 0)
        		L[i][j] = 0;
    		else if (X[i-1] == Y[j-1])
        		L[i][j] = L[i-1][j-1] + 1;
			else
        		L[i][j] = max(L[i-1][j], L[i][j-1]); }	}

	return L[one][second];
}


void insertVertex(struct graphHead *head, struct holder dataa){		//inserts vertex to create the whole graph 
	struct graphVertex *vertex = (struct graphVertex *)malloc(sizeof(struct graphVertex));

	vertex->next = NULL;
	vertex->Scanpath = dataa;
	vertex->neighbor = 0;
	vertex->processed = 0;
	vertex->firstArc = NULL;
	head->count++;
	
	if(head->first == NULL){
		head->first = vertex;	}
	else{
		struct graphVertex *tempVertex = head->first;
		while(tempVertex->next != NULL)
			tempVertex = tempVertex->next;
		tempVertex->next = vertex;	}
}


struct graphHead *createVertices(char *file1, char *file2){		//creates the vertices and returns the graph
	int i=0, j=0, size1, size2, personSize;
	size1 = countSize(file1);
	size2 = countSize(file2);
	Data1 *temp1;		//temp represents the temporary array of structure for aois values.
	Data2 *temp2;		
	temp1 = (Data1*)malloc(size1*sizeof(Data1));	
	temp2 = (Data2*)malloc(size2*sizeof(Data2));	
	
	FILE *inFile1;
	inFile1 = fopen(file1, "r");		//Opens the aois.txt file to read the information from the file.	
	if (inFile1 == NULL){
		printf("Opening file1 to read is not successful\n!");
		exit(1);	}

	char tempArray1[2*SIZE];
	while(!feof(inFile1)){	//Reads the information in file while it's not the end of file
		fgets(tempArray1, 2*SIZE, inFile1);
		strcpy(temp1[i].ElementName,strtok(tempArray1, " "));
		temp1[i].TopLeftX = atoi(strtok(NULL, " "));
		temp1[i].Width = atoi(strtok(NULL, " "));
		temp1[i].TopLeftY = atoi(strtok(NULL, " "));
		temp1[i].Height = atoi(strtok(NULL, " "));
		i++;	}
	
	FILE *inFile2;
	inFile2 = fopen(file2, "r");	//Opens the fixations.txt file to read the information from the file.
	if (inFile2 == NULL){
		printf("Opening file2 to read is not successful\n!");
		exit(1);	}
		
	char tempArray2[2*SIZE];
	while(j<size2){		//Reads the information in file till the end of the file
		fgets(tempArray2, 2*SIZE, inFile2);
		temp2[j].FixationID = atoi(strtok(tempArray2, " "));
		temp2[j].Xcoordinate = atoi(strtok(NULL, " "));
		temp2[j].Ycoordinate = atoi(strtok(NULL, " "));
		temp2[j].Duration = atoi(strtok(NULL, " "));
		j++;	}

	fclose(inFile1);
	fclose(inFile2);
		
	personSize = countPerson(file2);	
	Holder *Scanpath;
	Scanpath = (Holder*)malloc(SIZE * sizeof(Holder));
	
	int startPointX, startPointY, endPointX, endPointY, x, y;	// x and y represents the current the Xcoordinate and Ycoordinate values that we need to compare from file2
	int count=0, file1Count, k=0;	//file1Count represents the lines in the first (aois.txt) file so that we can visit all the lines for every line in fixations.txt file
	int tempLetterPosition[10];
	for(i=0 ; i<size2 ; i++){
		if(temp2[i].FixationID == 0){
			tempLetterPosition[k] = i;
			k++;	}
		for(j=0 ; j<size1 ; j++){
			x = temp2[i].Xcoordinate;
			y = temp2[i].Ycoordinate;
			startPointX = temp1[j].TopLeftX;
			endPointX = temp1[j].TopLeftX + temp1[j].Width;
			startPointY = temp1[j].TopLeftY;
			endPointY = temp1[j].TopLeftY + temp1[j].Height;
			while((x>=startPointX && x<=endPointX) && (y>=startPointY && y<=endPointY)){
				strcpy(Scanpath[count].letter,temp1[j].ElementName);
				break;	}	}
		count++;
	}
	
	tempLetterPosition[k] = size2;
	char letterArray[SIZE];
	j=0;
	for(i=0 ; i<personSize ; i++){
		strcpy(letterArray," ");
		while(j>=tempLetterPosition[i] && j<tempLetterPosition[i+1]){
			strcat(letterArray,Scanpath[j].letter);
			j++;	}
		strcpy(Scanpath[i].letter,letterArray);	}
		struct graphHead *head;
		head = createGraph();
		
		for (i=0 ; i<personSize ; i++){
			Scanpath[i].id=i+1;
			insertVertex(head,Scanpath[i]);	}
	
	return head;
}


struct graphHead *createEdges(struct graphHead *graph, int *counter){
	int i, j, LCS;
	struct graphVertex *Vtemp1;
	struct graphVertex *Vtemp2;
	
	Vtemp1 = graph->first;
	for(i=0 ; i<counter ; i++){
		Vtemp2 = graph->first;
		for(j=0 ; j<counter ; j++){
			LCS = lcs(Vtemp1->Scanpath.letter,Vtemp2->Scanpath.letter,strlen(Vtemp1->Scanpath.letter),strlen(Vtemp2->Scanpath.letter));
			if(LCS>=5)
				insertArc(graph,Vtemp1->Scanpath.id,Vtemp2->Scanpath.id,LCS);
			Vtemp2 = Vtemp2->next;	}
		Vtemp1 = Vtemp1->next;	}
	
	return graph;
}


int insertArc(struct graphHead *head, int fromKey, int toKey,int lcs){	//inserts the Arc whenever the lcs value is equal to or more than 5
	struct graphArc *arc = (struct graphArc *)malloc(sizeof(struct graphArc));
	struct graphVertex *fromVertex = NULL;
	struct graphVertex *toVertex = NULL;
	
	fromVertex = head->first;
	while(fromVertex!=NULL && fromVertex->Scanpath.id!=fromKey)
		fromVertex = fromVertex->next;
	
	if(fromVertex == NULL)
		return -2;	//fromVertex is not found!
		
	toVertex = head->first;
	while(toVertex!=NULL && toVertex->Scanpath.id!=toKey)
		toVertex = toVertex->next;
		
	if(toVertex == NULL)
		return -3;	//toVertex is not found!
	
	fromVertex->neighbor++;
	
	arc->destination = toVertex;
	arc->lcs=lcs;
	arc->nextArc = NULL;
	
	if(fromVertex->firstArc == NULL)
		fromVertex->firstArc = arc;
	else{
		struct graphArc *tempArc = fromVertex->firstArc;
		while(tempArc->nextArc != NULL)
			tempArc = tempArc->nextArc;
		tempArc->nextArc = arc;	}

	return 1;	//Successful operation!
}


void printGraph(struct graphHead *head){
	struct graphVertex *tempVertex = NULL;
	struct graphArc *tempArc = NULL;
	
	tempVertex = head->first;
	
	while(tempVertex != NULL){
		printf("\nData: %d", tempVertex->Scanpath.id);
		tempArc = tempVertex->firstArc;
		while(tempArc != NULL){
			printf("-> %d| %d", tempArc->destination->Scanpath.id,tempArc->	lcs);
			tempArc = tempArc->nextArc;	}
		tempVertex = tempVertex->next;	}
}


