
//leaderboadrMaker, sortingCriteria(1-actual win rate, 2-expected win rate, 3-expectation skew), ChampionDataFile, BattlesDataFile

#include <stdio.h>  
#include <string.h>
#include<stdlib.h>
#define SIZE 50

typedef struct data{
   	char name[SIZE];
   	double expectedWinRate;
   	int NumberOfBattles;
   	int NumberOfWins;
   	float ActualWinRate;
   	float ExpectationSkew;
   } Data;
   
int countChampions(char *);
char* initializeChampions(char *);
void getBattleData(Data *, char *, int);
void computeWinRate(Data *, int);
void swap(Data *, Data *);
int compare(int, int);
void heapify(Data [], int, int, int);
void heapSort(Data *, int, int);
void printLeaderboard(Data *, int);

int main(int argc, char *argv[] )  {   
	int i, size, criteria;
 	char filename[SIZE], filename2[SIZE];	//filename refers to the champions.txt and filename2 refers to battles.txt file.
   	strcpy(filename,argv[3]);	//This line takes the file name from the command-line and copies it to an array to hold it for further use. 	
   	size = countChampions(filename);
   	Data *Champions;	//We create an array of structure dynamically to get the array as an output of initializeChampions function
	Champions = initializeChampions(filename);
	strcpy(filename2,argv[4]);	//This line takes the file name from the comman-line and copies it as a filename battles.txt.
	getBattleData(Champions, filename2, size);
   	computeWinRate(Champions, size);
   	criteria = atoi(argv[2]);
   	heapSort(Champions, criteria, size);
  	printLeaderboard(Champions, size);
   
   return 0;
}  


//Helper function to get the number of the champions in order to create an array with an appropriate size.
int countChampions(char *filename){	
	FILE *inFile;
	inFile = fopen(filename, "r");		//Opens the file to read the information from the file.
	if (inFile == NULL){
		printf("Opening file to read is not successful\n!");
		exit(1);	}
		
	int counter=0;		//Counter to count the lines to get the number of champions in the file.
	char tempArray[SIZE];
	while(!feof(inFile)){
		fgets(tempArray, 2*SIZE, inFile);
		counter++;	}
	fclose(inFile);
	
	return counter;	
}


//Reads the champions.txt file and creates an array of structure for the champions.
char* initializeChampions(char *filename){
	int i=0;
	Data *temp;		//temp represents the temporary array of structure for champions. We'll return that champions array at the end.
	temp = (Data*)malloc(sizeof(Data));		//We allocate memory for temp array here.
	
	FILE *inFile;
	inFile = fopen(filename, "r");		//Opens the file to read the information from the file.
	if (inFile == NULL){
		printf("Opening file to read is not successful\n!");
		exit(1);	}
	
	char tempArray[2*SIZE];
	while(!feof(inFile)){	//Reads the information in file while it's not the end of file
		fgets(tempArray, 2*SIZE, inFile);
		strcpy(temp[i].name,strtok(tempArray, " "));
		temp[i].expectedWinRate = atof(strtok(NULL, " "));
		temp[i].ActualWinRate = 0;
		temp[i].ExpectationSkew = 0;
		temp[i].NumberOfBattles = 0;
		temp[i].NumberOfWins = 0;
		i++;	}
	fclose(inFile);		//Closes the file as we're done with reading it.
	
	return temp;
}


//Reads the battles.txt file and sets the necesssary numbers for the champions.
void getBattleData(Data *champions, char *filename, int size){
	FILE *inFile;
	inFile = fopen(filename, "r");		//Opens the file to read the information from the file.
	if (inFile == NULL){
		printf("Opening file to read is not successful\n!");
		exit(1);	}
	
	int i=0, j, k;
	char tempArray[SIZE], battle[10][size], p1[10][size], p2[10][size], winner[SIZE][size], holder[3*SIZE];		//We use an array to store all the battle informations.
	while(!feof(inFile)){	//Reads the information in file while it's not the end of file
		fgets(tempArray, SIZE, inFile);
		strcpy(battle[i],strtok(tempArray, " "));
		strcpy(p1[i],strtok(NULL, " "));	//p1 refers to participant 1
		strcpy(p2[i],strtok(NULL, " "));	//p2 refers to participant 2
		strcpy(holder,strtok(NULL, " "));	//As cursor is also included for the last line, like the cursor is moving to the next line, so the lenght of the winner[i] arrey is 1 more than its actual size.
		strncpy(winner[i],holder,strlen(holder)-1);	//So we can use a holder array to get the last elements of each line and then remove that last part from it. Then we get the size that it really has.

		for(j=0 ; j<size ; j++){
			if(!strcmp(winner[i],champions[j].name)){	//Compares the winners with each elements of the Champions array to check which participant won the battle.
				champions[j].NumberOfWins++;	}	}
				
		for(k=0 ; k<size ; k++){	//Checks all the participants attended to the battle and increase their number of battles.
			if(!strcmp(p1[i],champions[k].name)){	//Checks and increases the number for participant 1.
				champions[k].NumberOfBattles++;	}
			if(!strcmp(p2[i],champions[k].name)){	//Checks and increases the number for participant 2.
				champions[k].NumberOfBattles++;	}	}
				
		i++;	}
			
	fclose(inFile);		//Closes the file as we're done with reading it.
}


//This function takes the Champions array and traverses it, and then computes the actual win rate and expectation skew for every champion.
void computeWinRate(Data *champions, int size){
	int i;
	float winRateRatio[size];
	for(i=0 ; i<size ; i++){
		champions[i].ActualWinRate = champions[i].NumberOfWins / (float)champions[i].NumberOfBattles ;
		winRateRatio[i] = champions[i].ActualWinRate / champions[i].expectedWinRate;
		champions[i].ExpectationSkew = fabs(winRateRatio[i] - 1);	}
}


//This function swaps 2 numbers to use it in HheapSort 
void swap(Data *num1, Data *num2){
	Data temp = *num1;
	*num1 = *num2;
	*num2 = temp;	
}


//This function compares two numbers to check if they're equal
int compare(int a, int b){
	if(a==b)
		return 0;
	else if(a>b)
		return 1;
	else
		return -2;
}

//To heapify a subtree with an index of i and size that coming from the champions array size.
void heapify(Data *array, int size, int i, int criteria){
	int largest, left, right;
	largest = i;
	left = 2*i+1;
	right = 2*i+2;
	
	if(criteria==1){
		if(left<size && compare(array[left].ActualWinRate,array[largest].ActualWinRate)>0)	//if left child is larger than root, we copy the left value to the largest value.
			largest = left;
		if(right<size && compare(array[right].ActualWinRate,array[largest].ActualWinRate)>0)	//if right child is larger than root, we copy the right value to the largest value.
			largest = right;
		if(largest != i){	//execute the following lines if largest value is not in the root.
			swap(&array[i], &array[largest]);
			heapify(array, size, largest, criteria);	}	//we apply the heapify recursively to the sub-trees.
	}
	
	else if(criteria==2){
		if(left<size && compare(array[left].expectedWinRate,array[largest].expectedWinRate)>0)	//if left child is larger than root, we copy the left value to the largest value.
			largest = left;
		if(right<size && compare(array[right].expectedWinRate,array[largest].expectedWinRate)>0)	//if right child is larger than root, we copy the right value to the largest value.
			largest = right;
		if(largest != i){	//execute the following lines if largest value is not in the root.
			swap(&array[i], &array[largest]);
			heapify(array, size, largest, criteria);	}	//we apply the heapify recursively to the sub-trees.
	}
	
	else {							//criteria==3 option
		if(left<size && compare(array[left].ExpectationSkew,array[largest].ExpectationSkew)>0)	//if left child is larger than root, we copy the left value to the largest value.
			largest = left;
		if(right<size && compare(array[right].ExpectationSkew,array[largest].ExpectationSkew)>0)	//if right child is larger than root, we copy the right value to the largest value.
			largest = right;
		if(largest != i){	//execute the following lines if largest value is not in the root.
			swap(&array[i], &array[largest]);
			heapify(array, size, largest, criteria);	}	//we apply the heapify recursively to the sub-trees.
	}	
}


//This function sorts the data based on the criteria that a user enters to the command-line. So we basically applying BuildHeap algorithm here.
void heapSort(Data *champions, int criteria, int size){
	int i, startIndex;	
	startIndex =  ((size/2)-1);
	printf("The table content after applying HeapSort:\n");
	if(criteria<1 | criteria>3){
		printf("\nEntered value for the criteria input is invalid. Try again!\n");
		exit(1);	}
	for(i=startIndex ; i>=0 ; i--){
		heapify(champions, size, i, criteria);	}
	for(i=size-1 ; i>=0 ; i--){
		swap(&champions[0], &champions[i]);
		heapify(champions, i, 0, criteria);	}
}


//Takes the structure array that we want to print, array size and prints the content of it, Champions array in this case.
void printLeaderboard(Data *champions, int size){
	printf("\nChampion    Battles\tWin\tAWR\tEWR\tSkew\n ");
	int i;
	for (i=0 ; i<size ; i++){
		printf("%s\t\t", champions[i].name);
		printf("%d\t", champions[i].NumberOfBattles);
		printf("%d\t", champions[i].NumberOfWins);
		printf("%.2f\t", champions[i].ActualWinRate);
		printf("%.2f\t", champions[i].expectedWinRate);
		printf("%.2f\t\n", champions[i].ExpectationSkew);	}
}
